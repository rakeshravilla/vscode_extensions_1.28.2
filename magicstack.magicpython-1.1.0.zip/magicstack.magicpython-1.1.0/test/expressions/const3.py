T61STRING = 20
T61_STRING
T_STRING
_T_S_T_R_I_N_G_
A_CLASS

# not enough upper-case letters in the beginning
_T_s_TRING
A_Class




T61STRING     : constant.other.caps.python, source.python
              : source.python
=             : keyword.operator.assignment.python, source.python
              : source.python
20            : constant.numeric.dec.python, source.python
T61_STRING    : constant.other.caps.python, source.python
T_STRING      : constant.other.caps.python, source.python
_T_S_T_R_I_N_G_ : constant.other.caps.python, source.python
A_CLASS       : constant.other.caps.python, source.python
              : source.python
#             : comment.line.number-sign.python, punctuation.definition.comment.python, source.python
 not enough upper-case letters in the beginning : comment.line.number-sign.python, source.python
_T_s_TRING    : source.python
A_Class       : source.python
