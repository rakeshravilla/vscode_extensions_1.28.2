for a, b, c in b:
    pass
else:
    1/0



for           : keyword.control.flow.python, source.python
              : source.python
a             : source.python
,             : punctuation.separator.element.python, source.python
              : source.python
b             : source.python
,             : punctuation.separator.element.python, source.python
              : source.python
c             : source.python
              : source.python
in            : keyword.operator.logical.python, source.python
              : source.python
b             : source.python
:             : punctuation.separator.colon.python, source.python
              : source.python
pass          : keyword.control.flow.python, source.python
else          : keyword.control.flow.python, source.python
:             : punctuation.separator.colon.python, source.python
              : source.python
1             : constant.numeric.dec.python, source.python
/             : keyword.operator.arithmetic.python, source.python
0             : constant.numeric.dec.python, source.python
