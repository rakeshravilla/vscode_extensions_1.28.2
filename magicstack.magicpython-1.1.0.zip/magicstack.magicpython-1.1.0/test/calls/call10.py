x = foo(True,
        3 * 4,
        *a,
        **bar)





x             : source.python
              : source.python
=             : keyword.operator.assignment.python, source.python
              : source.python
foo           : meta.function-call.generic.python, meta.function-call.python, source.python
(             : meta.function-call.python, punctuation.definition.arguments.begin.python, source.python
True          : constant.language.python, meta.function-call.arguments.python, meta.function-call.python, source.python
,             : meta.function-call.arguments.python, meta.function-call.python, punctuation.separator.arguments.python, source.python
              : meta.function-call.arguments.python, meta.function-call.python, source.python
3             : constant.numeric.dec.python, meta.function-call.arguments.python, meta.function-call.python, source.python
              : meta.function-call.arguments.python, meta.function-call.python, source.python
*             : keyword.operator.arithmetic.python, meta.function-call.arguments.python, meta.function-call.python, source.python
              : meta.function-call.arguments.python, meta.function-call.python, source.python
4             : constant.numeric.dec.python, meta.function-call.arguments.python, meta.function-call.python, source.python
,             : meta.function-call.arguments.python, meta.function-call.python, punctuation.separator.arguments.python, source.python
              : meta.function-call.arguments.python, meta.function-call.python, source.python
*             : keyword.operator.unpacking.arguments.python, meta.function-call.arguments.python, meta.function-call.python, source.python
a             : meta.function-call.arguments.python, meta.function-call.python, source.python
,             : meta.function-call.arguments.python, meta.function-call.python, punctuation.separator.arguments.python, source.python
              : meta.function-call.arguments.python, meta.function-call.python, source.python
**            : keyword.operator.unpacking.arguments.python, meta.function-call.arguments.python, meta.function-call.python, source.python
bar           : meta.function-call.arguments.python, meta.function-call.python, source.python
)             : meta.function-call.python, punctuation.definition.arguments.end.python, source.python
