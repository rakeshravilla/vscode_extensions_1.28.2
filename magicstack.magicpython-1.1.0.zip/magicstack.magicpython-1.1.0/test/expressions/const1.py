QQQQ QQQQ_123 QQQQ123 PROTOCOL_v2 QQQ.bar baz.AA_a _AAA foo._AAA
QQQq QQQq123 self.FOOO() _ _1 __1 _1A  __1A _a __a __ ___ ___a ___1 __aA ___Aa



QQQQ          : constant.other.caps.python, source.python
              : source.python
QQQQ_123      : constant.other.caps.python, source.python
              : source.python
QQQQ123       : constant.other.caps.python, source.python
              : source.python
PROTOCOL_v2   : constant.other.caps.python, source.python
              : source.python
QQQ           : constant.other.caps.python, source.python
.             : punctuation.separator.period.python, source.python
bar           : source.python
              : source.python
baz           : source.python
.             : punctuation.separator.period.python, source.python
AA_a          : constant.other.caps.python, source.python
              : source.python
_AAA          : constant.other.caps.python, source.python
              : source.python
foo           : source.python
.             : punctuation.separator.period.python, source.python
_AAA          : constant.other.caps.python, source.python
QQQq          : source.python
              : source.python
QQQq123       : source.python
              : source.python
self          : source.python, variable.language.special.self.python
.             : punctuation.separator.period.python, source.python
FOOO          : meta.function-call.generic.python, meta.function-call.python, source.python
(             : meta.function-call.python, punctuation.definition.arguments.begin.python, source.python
)             : meta.function-call.python, punctuation.definition.arguments.end.python, source.python
              : source.python
_             : source.python
              : source.python
_1            : source.python
              : source.python
__1           : source.python
              : source.python
_1A           : source.python
              : source.python
__1A          : source.python
              : source.python
_a            : source.python
              : source.python
__a           : source.python
              : source.python
__            : source.python
              : source.python
___           : source.python
              : source.python
___a          : source.python
              : source.python
___1          : source.python
              : source.python
__aA          : source.python
              : source.python
___Aa         : source.python
