"TE\"ST"
r"TE\"ST"
R"TE\"ST"

u"TEST"
U"TEST"
b"TEST"
B"TEST"



"             : punctuation.definition.string.begin.python, source.python, string.quoted.docstring.single.python
TE            : source.python, string.quoted.docstring.single.python
\"            : constant.character.escape.python, source.python, string.quoted.docstring.single.python
ST            : source.python, string.quoted.docstring.single.python
"             : punctuation.definition.string.end.python, source.python, string.quoted.docstring.single.python
r             : source.python, storage.type.string.python, string.quoted.docstring.raw.single.python
"             : punctuation.definition.string.begin.python, source.python, string.quoted.docstring.raw.single.python
TE            : source.python, string.quoted.docstring.raw.single.python
\"            : source.python, string.quoted.docstring.raw.single.python
ST            : source.python, string.quoted.docstring.raw.single.python
"             : punctuation.definition.string.end.python, source.python, string.quoted.docstring.raw.single.python
R             : source.python, storage.type.string.python, string.quoted.docstring.raw.single.python
"             : punctuation.definition.string.begin.python, source.python, string.quoted.docstring.raw.single.python
TE            : source.python, string.quoted.docstring.raw.single.python
\"            : source.python, string.quoted.docstring.raw.single.python
ST            : source.python, string.quoted.docstring.raw.single.python
"             : punctuation.definition.string.end.python, source.python, string.quoted.docstring.raw.single.python
              : source.python
u             : source.python, storage.type.string.python, string.quoted.single.python
"             : punctuation.definition.string.begin.python, source.python, string.quoted.single.python
TEST          : source.python, string.quoted.single.python
"             : punctuation.definition.string.end.python, source.python, string.quoted.single.python
U             : source.python, storage.type.string.python, string.quoted.single.python
"             : punctuation.definition.string.begin.python, source.python, string.quoted.single.python
TEST          : source.python, string.quoted.single.python
"             : punctuation.definition.string.end.python, source.python, string.quoted.single.python
b             : source.python, storage.type.string.python, string.quoted.binary.single.python
"             : punctuation.definition.string.begin.python, source.python, string.quoted.binary.single.python
TEST          : source.python, string.quoted.binary.single.python
"             : punctuation.definition.string.end.python, source.python, string.quoted.binary.single.python
B             : source.python, storage.type.string.python, string.quoted.binary.single.python
"             : punctuation.definition.string.begin.python, source.python, string.quoted.binary.single.python
TEST          : source.python, string.quoted.binary.single.python
"             : punctuation.definition.string.end.python, source.python, string.quoted.binary.single.python
