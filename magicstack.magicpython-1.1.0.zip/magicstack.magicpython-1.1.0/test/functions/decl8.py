def foo(a=1**1, *b:3*2=1*2, **a=1*2**3): pass



def           : meta.function.python, source.python, storage.type.function.python
              : meta.function.python, source.python
foo           : entity.name.function.python, meta.function.python, source.python
(             : meta.function.parameters.python, meta.function.python, punctuation.definition.parameters.begin.python, source.python
a             : meta.function.parameters.python, meta.function.python, source.python, variable.parameter.function.language.python
=             : keyword.operator.python, meta.function.parameters.python, meta.function.python, source.python
1             : constant.numeric.dec.python, meta.function.parameters.python, meta.function.python, source.python
**            : keyword.operator.arithmetic.python, meta.function.parameters.python, meta.function.python, source.python
1             : constant.numeric.dec.python, meta.function.parameters.python, meta.function.python, source.python
,             : meta.function.parameters.python, meta.function.python, punctuation.separator.parameters.python, source.python
              : meta.function.parameters.python, meta.function.python, source.python
*             : keyword.operator.unpacking.parameter.python, meta.function.parameters.python, meta.function.python, source.python
b             : meta.function.parameters.python, meta.function.python, source.python, variable.parameter.function.language.python
:             : meta.function.parameters.python, meta.function.python, punctuation.separator.annotation.python, source.python
3             : constant.numeric.dec.python, meta.function.parameters.python, meta.function.python, source.python
*             : keyword.operator.arithmetic.python, meta.function.parameters.python, meta.function.python, source.python
2             : constant.numeric.dec.python, meta.function.parameters.python, meta.function.python, source.python
=             : keyword.operator.assignment.python, meta.function.parameters.python, meta.function.python, source.python
1             : constant.numeric.dec.python, meta.function.parameters.python, meta.function.python, source.python
*             : keyword.operator.arithmetic.python, meta.function.parameters.python, meta.function.python, source.python
2             : constant.numeric.dec.python, meta.function.parameters.python, meta.function.python, source.python
,             : meta.function.parameters.python, meta.function.python, punctuation.separator.parameters.python, source.python
              : meta.function.parameters.python, meta.function.python, source.python
**            : keyword.operator.unpacking.parameter.python, meta.function.parameters.python, meta.function.python, source.python
a             : meta.function.parameters.python, meta.function.python, source.python, variable.parameter.function.language.python
=             : keyword.operator.python, meta.function.parameters.python, meta.function.python, source.python
1             : constant.numeric.dec.python, meta.function.parameters.python, meta.function.python, source.python
*             : keyword.operator.arithmetic.python, meta.function.parameters.python, meta.function.python, source.python
2             : constant.numeric.dec.python, meta.function.parameters.python, meta.function.python, source.python
**            : keyword.operator.arithmetic.python, meta.function.parameters.python, meta.function.python, source.python
3             : constant.numeric.dec.python, meta.function.parameters.python, meta.function.python, source.python
)             : meta.function.parameters.python, meta.function.python, punctuation.definition.parameters.end.python, source.python
:             : meta.function.python, punctuation.section.function.begin.python, source.python
              : source.python
pass          : keyword.control.flow.python, source.python
