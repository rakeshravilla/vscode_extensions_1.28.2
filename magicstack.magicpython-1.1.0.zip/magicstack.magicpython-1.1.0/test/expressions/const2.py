_AA __AB ___AA
_A __A ___A A1 A_1 _A_1 A_foo



_AA           : constant.other.caps.python, source.python
              : source.python
__AB          : constant.other.caps.python, source.python
              : source.python
___AA         : constant.other.caps.python, source.python
_A            : source.python
              : source.python
__A           : source.python
              : source.python
___A          : source.python
              : source.python
A1            : source.python
              : source.python
A_1           : source.python
              : source.python
_A_1          : source.python
              : source.python
A_foo         : source.python
