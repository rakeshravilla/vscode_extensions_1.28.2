r'''Module docstring

    Some text followed by code sample:
    >>> for a in foo(2, b=1,
    ...                 c=3):
    ...   print(a)
    0
    1
'''



r             : source.python, storage.type.string.python, string.quoted.docstring.raw.multi.python
'''           : punctuation.definition.string.begin.python, source.python, string.quoted.docstring.raw.multi.python
Module docstring : source.python, string.quoted.docstring.raw.multi.python
              : source.python, string.quoted.docstring.raw.multi.python
    Some text followed by code sample: : source.python, string.quoted.docstring.raw.multi.python
              : source.python, string.quoted.docstring.raw.multi.python
>>>           : keyword.control.flow.python, source.python, string.quoted.docstring.raw.multi.python
for a in foo(2, b=1, : source.python, string.quoted.docstring.raw.multi.python
              : source.python, string.quoted.docstring.raw.multi.python
...           : keyword.control.flow.python, source.python, string.quoted.docstring.raw.multi.python
                c=3): : source.python, string.quoted.docstring.raw.multi.python
              : source.python, string.quoted.docstring.raw.multi.python
...           : keyword.control.flow.python, source.python, string.quoted.docstring.raw.multi.python
  print(a)    : source.python, string.quoted.docstring.raw.multi.python
    0         : source.python, string.quoted.docstring.raw.multi.python
    1         : source.python, string.quoted.docstring.raw.multi.python
'''           : punctuation.definition.string.end.python, source.python, string.quoted.docstring.raw.multi.python
