a.True = b.False = d.None



a             : source.python
.             : punctuation.separator.period.python, source.python
True          : keyword.illegal.name.python, source.python
              : source.python
=             : keyword.operator.assignment.python, source.python
              : source.python
b             : source.python
.             : punctuation.separator.period.python, source.python
False         : keyword.illegal.name.python, source.python
              : source.python
=             : keyword.operator.assignment.python, source.python
              : source.python
d             : source.python
.             : punctuation.separator.period.python, source.python
None          : keyword.illegal.name.python, source.python
