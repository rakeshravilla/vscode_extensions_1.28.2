1_234.567_890
0.456_789
000.000_1
.012_34
1_234e5_000
1_234e-5_000
000_123e-000_5
1_234.567_8e+5_000
0.456_78e-5_000



1_234.567_890 : constant.numeric.float.python, source.python
0.456_789     : constant.numeric.float.python, source.python
000.000_1     : constant.numeric.float.python, source.python
.012_34       : constant.numeric.float.python, source.python
1_234e5_000   : constant.numeric.float.python, source.python
1_234e-5_000  : constant.numeric.float.python, source.python
000_123e-000_5 : constant.numeric.float.python, source.python
1_234.567_8e+5_000 : constant.numeric.float.python, source.python
0.456_78e-5_000 : constant.numeric.float.python, source.python
