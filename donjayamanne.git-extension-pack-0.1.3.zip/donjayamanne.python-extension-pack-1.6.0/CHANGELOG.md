## 1.6.0

- Changes to how extensions are bundled.

## 1.5.0

- Remove Jupyter extension.

## 1.4.0

- Remove VS Live Share (as this not specific to Python).

## 1.3.0

- Included Visual Studio IntelliCode.

## 1.2.0

- Included VS Live Share.
- Update recommented Django extensions.

## 1.1.0

- Updated to change the id of the Python extension.

## 1.0.0

- Oops, fixed repo links.

## 0.0.1

- Initial release.
