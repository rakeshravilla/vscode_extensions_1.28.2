from....foo import a
from...foo import b
from..foo import c
from.foo import d



from          : keyword.control.import.python, source.python
....          : punctuation.separator.period.python, source.python
foo           : source.python
              : source.python
import        : keyword.control.import.python, source.python
              : source.python
a             : source.python
from          : keyword.control.import.python, source.python
...           : punctuation.separator.period.python, source.python
foo           : source.python
              : source.python
import        : keyword.control.import.python, source.python
              : source.python
b             : source.python
from          : keyword.control.import.python, source.python
..            : punctuation.separator.period.python, source.python
foo           : source.python
              : source.python
import        : keyword.control.import.python, source.python
              : source.python
c             : source.python
from          : keyword.control.import.python, source.python
.             : punctuation.separator.period.python, source.python
foo           : source.python
              : source.python
import        : keyword.control.import.python, source.python
              : source.python
d             : source.python
