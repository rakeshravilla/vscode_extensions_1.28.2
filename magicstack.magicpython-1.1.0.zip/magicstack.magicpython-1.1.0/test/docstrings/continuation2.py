'
'
# comment



'             : punctuation.definition.string.begin.python, source.python, string.quoted.docstring.single.python
              : invalid.illegal.newline.python, source.python, string.quoted.docstring.single.python
'             : punctuation.definition.string.begin.python, source.python, string.quoted.docstring.single.python
              : invalid.illegal.newline.python, source.python, string.quoted.docstring.single.python
#             : comment.line.number-sign.python, punctuation.definition.comment.python, source.python
 comment      : comment.line.number-sign.python, source.python
