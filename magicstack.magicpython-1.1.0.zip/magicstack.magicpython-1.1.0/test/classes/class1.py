class Foo -> None: pass



class         : source.python, storage.type.class.python
              : source.python
Foo           : source.python
              : source.python
->            : invalid.illegal.annotation.python, source.python
              : source.python
None          : constant.language.python, source.python
:             : punctuation.separator.colon.python, source.python
              : source.python
pass          : keyword.control.flow.python, source.python
