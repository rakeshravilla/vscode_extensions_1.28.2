class Foo:
    def __init__(self):
        super().__init__(foo=1)
        super(). __init__(foo=1)
        super(). \
__init__(foo=1)
        __init__(foo=1)

        foo.__init__(bar=1)
        __init__(bar=1)
        if:
            __init__(bar=1)




class         : meta.class.python, source.python, storage.type.class.python
              : meta.class.python, source.python
Foo           : entity.name.type.class.python, meta.class.python, source.python
:             : meta.class.python, punctuation.section.class.begin.python, source.python
              : meta.function.python, source.python
def           : meta.function.python, source.python, storage.type.function.python
              : meta.function.python, source.python
__init__      : meta.function.python, source.python, support.function.magic.python
(             : meta.function.parameters.python, meta.function.python, punctuation.definition.parameters.begin.python, source.python
self          : meta.function.parameters.python, meta.function.python, source.python, variable.parameter.function.language.python, variable.parameter.function.language.special.self.python
)             : meta.function.parameters.python, meta.function.python, punctuation.definition.parameters.end.python, source.python
:             : meta.function.python, punctuation.section.function.begin.python, source.python
              : source.python
super         : meta.function-call.python, source.python, support.type.python
(             : meta.function-call.python, punctuation.definition.arguments.begin.python, source.python
)             : meta.function-call.python, punctuation.definition.arguments.end.python, source.python
.             : punctuation.separator.period.python, source.python
__init__      : meta.function-call.python, source.python, support.function.magic.python
(             : meta.function-call.python, punctuation.definition.arguments.begin.python, source.python
foo           : meta.function-call.arguments.python, meta.function-call.python, source.python, variable.parameter.function-call.python
=             : keyword.operator.assignment.python, meta.function-call.arguments.python, meta.function-call.python, source.python
1             : constant.numeric.dec.python, meta.function-call.arguments.python, meta.function-call.python, source.python
)             : meta.function-call.python, punctuation.definition.arguments.end.python, source.python
              : source.python
super         : meta.function-call.python, source.python, support.type.python
(             : meta.function-call.python, punctuation.definition.arguments.begin.python, source.python
)             : meta.function-call.python, punctuation.definition.arguments.end.python, source.python
.             : punctuation.separator.period.python, source.python
              : source.python
__init__      : meta.function-call.python, source.python, support.function.magic.python
(             : meta.function-call.python, punctuation.definition.arguments.begin.python, source.python
foo           : meta.function-call.arguments.python, meta.function-call.python, source.python, variable.parameter.function-call.python
=             : keyword.operator.assignment.python, meta.function-call.arguments.python, meta.function-call.python, source.python
1             : constant.numeric.dec.python, meta.function-call.arguments.python, meta.function-call.python, source.python
)             : meta.function-call.python, punctuation.definition.arguments.end.python, source.python
              : source.python
super         : meta.function-call.python, source.python, support.type.python
(             : meta.function-call.python, punctuation.definition.arguments.begin.python, source.python
)             : meta.function-call.python, punctuation.definition.arguments.end.python, source.python
.             : punctuation.separator.period.python, source.python
              : source.python
\             : punctuation.separator.continuation.line.python, source.python
              : source.python
__init__      : meta.function-call.python, source.python, support.function.magic.python
(             : meta.function-call.python, punctuation.definition.arguments.begin.python, source.python
foo           : meta.function-call.arguments.python, meta.function-call.python, source.python, variable.parameter.function-call.python
=             : keyword.operator.assignment.python, meta.function-call.arguments.python, meta.function-call.python, source.python
1             : constant.numeric.dec.python, meta.function-call.arguments.python, meta.function-call.python, source.python
)             : meta.function-call.python, punctuation.definition.arguments.end.python, source.python
              : source.python
__init__      : meta.function-call.python, source.python, support.function.magic.python
(             : meta.function-call.python, punctuation.definition.arguments.begin.python, source.python
foo           : meta.function-call.arguments.python, meta.function-call.python, source.python, variable.parameter.function-call.python
=             : keyword.operator.assignment.python, meta.function-call.arguments.python, meta.function-call.python, source.python
1             : constant.numeric.dec.python, meta.function-call.arguments.python, meta.function-call.python, source.python
)             : meta.function-call.python, punctuation.definition.arguments.end.python, source.python
              : source.python
              : source.python
foo           : source.python
.             : punctuation.separator.period.python, source.python
__init__      : meta.function-call.python, source.python, support.function.magic.python
(             : meta.function-call.python, punctuation.definition.arguments.begin.python, source.python
bar           : meta.function-call.arguments.python, meta.function-call.python, source.python, variable.parameter.function-call.python
=             : keyword.operator.assignment.python, meta.function-call.arguments.python, meta.function-call.python, source.python
1             : constant.numeric.dec.python, meta.function-call.arguments.python, meta.function-call.python, source.python
)             : meta.function-call.python, punctuation.definition.arguments.end.python, source.python
              : source.python
__init__      : meta.function-call.python, source.python, support.function.magic.python
(             : meta.function-call.python, punctuation.definition.arguments.begin.python, source.python
bar           : meta.function-call.arguments.python, meta.function-call.python, source.python, variable.parameter.function-call.python
=             : keyword.operator.assignment.python, meta.function-call.arguments.python, meta.function-call.python, source.python
1             : constant.numeric.dec.python, meta.function-call.arguments.python, meta.function-call.python, source.python
)             : meta.function-call.python, punctuation.definition.arguments.end.python, source.python
              : source.python
if            : keyword.control.flow.python, source.python
:             : punctuation.separator.colon.python, source.python
              : source.python
__init__      : meta.function-call.python, source.python, support.function.magic.python
(             : meta.function-call.python, punctuation.definition.arguments.begin.python, source.python
bar           : meta.function-call.arguments.python, meta.function-call.python, source.python, variable.parameter.function-call.python
=             : keyword.operator.assignment.python, meta.function-call.arguments.python, meta.function-call.python, source.python
1             : constant.numeric.dec.python, meta.function-call.arguments.python, meta.function-call.python, source.python
)             : meta.function-call.python, punctuation.definition.arguments.end.python, source.python
