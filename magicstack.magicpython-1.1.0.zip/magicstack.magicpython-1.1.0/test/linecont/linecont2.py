1 + \
 3



1             : constant.numeric.dec.python, source.python
              : source.python
+             : keyword.operator.arithmetic.python, source.python
              : source.python
\             : punctuation.separator.continuation.line.python, source.python
              : source.python
              : source.python
3             : constant.numeric.dec.python, source.python
