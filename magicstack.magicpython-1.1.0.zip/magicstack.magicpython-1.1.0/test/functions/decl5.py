def f()->123:pass



def           : meta.function.python, source.python, storage.type.function.python
              : meta.function.python, source.python
f             : entity.name.function.python, meta.function.python, source.python
(             : meta.function.parameters.python, meta.function.python, punctuation.definition.parameters.begin.python, source.python
)             : meta.function.parameters.python, meta.function.python, punctuation.definition.parameters.end.python, source.python
->            : meta.function.python, punctuation.separator.annotation.result.python, source.python
123           : constant.numeric.dec.python, meta.function.python, source.python
:             : meta.function.python, punctuation.section.function.begin.python, source.python
pass          : keyword.control.flow.python, source.python
