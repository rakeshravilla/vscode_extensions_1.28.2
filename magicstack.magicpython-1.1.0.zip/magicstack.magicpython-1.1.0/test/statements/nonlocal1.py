nonlocal a, b, c



nonlocal      : source.python, storage.modifier.declaration.python
              : source.python
a             : source.python
,             : punctuation.separator.element.python, source.python
              : source.python
b             : source.python
,             : punctuation.separator.element.python, source.python
              : source.python
c             : source.python
