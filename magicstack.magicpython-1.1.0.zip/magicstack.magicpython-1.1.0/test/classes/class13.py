class A(*a, **b): pass



class         : meta.class.python, source.python, storage.type.class.python
              : meta.class.python, source.python
A             : entity.name.type.class.python, meta.class.python, source.python
(             : meta.class.inheritance.python, meta.class.python, punctuation.definition.inheritance.begin.python, source.python
*             : keyword.operator.unpacking.arguments.python, meta.class.inheritance.python, meta.class.python, source.python
a             : entity.other.inherited-class.python, meta.class.inheritance.python, meta.class.python, source.python
,             : meta.class.inheritance.python, meta.class.python, punctuation.separator.inheritance.python, source.python
              : meta.class.inheritance.python, meta.class.python, source.python
**            : keyword.operator.unpacking.arguments.python, meta.class.inheritance.python, meta.class.python, source.python
b             : entity.other.inherited-class.python, meta.class.inheritance.python, meta.class.python, source.python
)             : meta.class.inheritance.python, meta.class.python, punctuation.definition.inheritance.end.python, source.python
:             : meta.class.python, punctuation.section.class.begin.python, source.python
              : source.python
pass          : keyword.control.flow.python, source.python
