def get_streaks(s) \
    -> 'spam': pass



def           : meta.function.python, source.python, storage.type.function.python
              : meta.function.python, source.python
get_streaks   : entity.name.function.python, meta.function.python, source.python
(             : meta.function.parameters.python, meta.function.python, punctuation.definition.parameters.begin.python, source.python
s             : meta.function.parameters.python, meta.function.python, source.python, variable.parameter.function.language.python
)             : meta.function.parameters.python, meta.function.python, punctuation.definition.parameters.end.python, source.python
              : meta.function.python, source.python
\             : meta.function.python, punctuation.separator.continuation.line.python, source.python
              : meta.function.python, source.python
              : meta.function.python, source.python
->            : meta.function.python, punctuation.separator.annotation.result.python, source.python
              : meta.function.python, source.python
'             : meta.function.python, punctuation.definition.string.begin.python, source.python, string.quoted.single.python
spam          : meta.function.python, source.python, string.quoted.single.python
'             : meta.function.python, punctuation.definition.string.end.python, source.python, string.quoted.single.python
:             : meta.function.python, punctuation.section.function.begin.python, source.python
              : source.python
pass          : keyword.control.flow.python, source.python
