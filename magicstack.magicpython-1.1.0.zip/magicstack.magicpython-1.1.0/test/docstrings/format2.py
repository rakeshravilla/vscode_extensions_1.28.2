'''{foo}'''




'''           : punctuation.definition.string.begin.python, source.python, string.quoted.docstring.multi.python
{foo}         : source.python, string.quoted.docstring.multi.python
'''           : punctuation.definition.string.end.python, source.python, string.quoted.docstring.multi.python
