r'''Module docstring

    %(language)s has %(number)03d quote types.
'''



r             : source.python, storage.type.string.python, string.quoted.docstring.raw.multi.python
'''           : punctuation.definition.string.begin.python, source.python, string.quoted.docstring.raw.multi.python
Module docstring : source.python, string.quoted.docstring.raw.multi.python
              : source.python, string.quoted.docstring.raw.multi.python
    %(language)s has %(number)03d quote types. : source.python, string.quoted.docstring.raw.multi.python
'''           : punctuation.definition.string.end.python, source.python, string.quoted.docstring.raw.multi.python
