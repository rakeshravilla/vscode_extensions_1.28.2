a @= b
a -= c
a ^= d



a             : source.python
              : source.python
@=            : keyword.operator.assignment.python, source.python
              : source.python
b             : source.python
a             : source.python
              : source.python
-=            : keyword.operator.assignment.python, source.python
              : source.python
c             : source.python
a             : source.python
              : source.python
^=            : keyword.operator.assignment.python, source.python
              : source.python
d             : source.python
