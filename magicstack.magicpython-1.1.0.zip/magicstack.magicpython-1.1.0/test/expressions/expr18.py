a.Exception
Exception.a



a             : source.python
.             : punctuation.separator.period.python, source.python
Exception     : source.python
Exception     : source.python, support.type.exception.python
.             : punctuation.separator.period.python, source.python
a             : source.python
