0o1234567
0O1234567
0o1_234_567
0b0000
0B0001
0b_0011_1001
0xabcdef01234567890
0XFF12
0xab_cd_ef_01_23_45_67_89_00

0o
0b
0x
0z

0b02
0x0z
0o90



0o            : constant.numeric.oct.python, source.python, storage.type.number.python
1234567       : constant.numeric.oct.python, source.python
0O            : constant.numeric.oct.python, source.python, storage.type.number.python
1234567       : constant.numeric.oct.python, source.python
0o            : constant.numeric.oct.python, source.python, storage.type.number.python
1_234_567     : constant.numeric.oct.python, source.python
0b            : constant.numeric.bin.python, source.python, storage.type.number.python
0000          : constant.numeric.bin.python, source.python
0B            : constant.numeric.bin.python, source.python, storage.type.number.python
0001          : constant.numeric.bin.python, source.python
0b            : constant.numeric.bin.python, source.python, storage.type.number.python
_0011_1001    : constant.numeric.bin.python, source.python
0x            : constant.numeric.hex.python, source.python, storage.type.number.python
abcdef01234567890 : constant.numeric.hex.python, source.python
0X            : constant.numeric.hex.python, source.python, storage.type.number.python
FF12          : constant.numeric.hex.python, source.python
0x            : constant.numeric.hex.python, source.python, storage.type.number.python
ab_cd_ef_01_23_45_67_89_00 : constant.numeric.hex.python, source.python
              : source.python
0o            : invalid.illegal.name.python, source.python
0b            : invalid.illegal.name.python, source.python
0x            : invalid.illegal.name.python, source.python
0z            : invalid.illegal.name.python, source.python
              : source.python
0b02          : invalid.illegal.name.python, source.python
0x0z          : invalid.illegal.name.python, source.python
0o90          : invalid.illegal.name.python, source.python
