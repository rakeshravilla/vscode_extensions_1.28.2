---
name: 🚀 Feature request
about: This issue tracker is not for feature requests. Please suggest your idea here https://github.com/scalameta/metals-feature-requests
title: DO NOT OPEN FEATURE REQUEST HERE
labels: ''
assignees: ''

---

Please open feature requests here https://github.com/scalameta/metals-feature-requests

The main issue tracker is reserved for bug reports and issues with an assigned milestone.
