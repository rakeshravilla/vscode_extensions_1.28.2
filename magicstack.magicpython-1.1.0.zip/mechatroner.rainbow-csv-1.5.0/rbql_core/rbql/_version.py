# Explanation of this file purpose: https://stackoverflow.com/a/16084844/2898283
__version__ = '0.10.0'

