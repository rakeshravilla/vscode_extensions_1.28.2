a = r'(<\' for
a = r"(<\" for
a = r'[<\' for
a = r"[<\" for
a = r'(?=\' for
a = r"(?=\" for
a = r'(?P<a>\' for
a = r"(?P<a>\" for
a = r'(?<!a\' for
a = r"(?<!a\" for
return some



a             : source.python
              : source.python
=             : keyword.operator.assignment.python, source.python
              : source.python
r             : source.python, storage.type.string.python, string.regexp.quoted.single.python
'             : punctuation.definition.string.begin.python, source.python, string.regexp.quoted.single.python
(             : punctuation.parenthesis.begin.regexp, source.python, string.regexp.quoted.single.python, support.other.parenthesis.regexp
<             : source.python, string.regexp.quoted.single.python
\'            : constant.character.escape.regexp, source.python, string.regexp.quoted.single.python
 for          : source.python, string.regexp.quoted.single.python
              : invalid.illegal.newline.python, source.python, string.regexp.quoted.single.python
a             : source.python
              : source.python
=             : keyword.operator.assignment.python, source.python
              : source.python
r             : source.python, storage.type.string.python, string.regexp.quoted.single.python
"             : punctuation.definition.string.begin.python, source.python, string.regexp.quoted.single.python
(             : punctuation.parenthesis.begin.regexp, source.python, string.regexp.quoted.single.python, support.other.parenthesis.regexp
<             : source.python, string.regexp.quoted.single.python
\"            : constant.character.escape.regexp, source.python, string.regexp.quoted.single.python
 for          : source.python, string.regexp.quoted.single.python
              : invalid.illegal.newline.python, source.python, string.regexp.quoted.single.python
a             : source.python
              : source.python
=             : keyword.operator.assignment.python, source.python
              : source.python
r             : source.python, storage.type.string.python, string.regexp.quoted.single.python
'             : punctuation.definition.string.begin.python, source.python, string.regexp.quoted.single.python
[             : constant.other.set.regexp, meta.character.set.regexp, punctuation.character.set.begin.regexp, source.python, string.regexp.quoted.single.python
<             : constant.character.set.regexp, meta.character.set.regexp, source.python, string.regexp.quoted.single.python
\'            : constant.character.escape.regexp, meta.character.set.regexp, source.python, string.regexp.quoted.single.python
              : constant.character.set.regexp, meta.character.set.regexp, source.python, string.regexp.quoted.single.python
f             : constant.character.set.regexp, meta.character.set.regexp, source.python, string.regexp.quoted.single.python
o             : constant.character.set.regexp, meta.character.set.regexp, source.python, string.regexp.quoted.single.python
r             : constant.character.set.regexp, meta.character.set.regexp, source.python, string.regexp.quoted.single.python
              : invalid.illegal.newline.python, source.python, string.regexp.quoted.single.python
a             : source.python
              : source.python
=             : keyword.operator.assignment.python, source.python
              : source.python
r             : source.python, storage.type.string.python, string.regexp.quoted.single.python
"             : punctuation.definition.string.begin.python, source.python, string.regexp.quoted.single.python
[             : constant.other.set.regexp, meta.character.set.regexp, punctuation.character.set.begin.regexp, source.python, string.regexp.quoted.single.python
<             : constant.character.set.regexp, meta.character.set.regexp, source.python, string.regexp.quoted.single.python
\"            : constant.character.escape.regexp, meta.character.set.regexp, source.python, string.regexp.quoted.single.python
              : constant.character.set.regexp, meta.character.set.regexp, source.python, string.regexp.quoted.single.python
f             : constant.character.set.regexp, meta.character.set.regexp, source.python, string.regexp.quoted.single.python
o             : constant.character.set.regexp, meta.character.set.regexp, source.python, string.regexp.quoted.single.python
r             : constant.character.set.regexp, meta.character.set.regexp, source.python, string.regexp.quoted.single.python
              : invalid.illegal.newline.python, source.python, string.regexp.quoted.single.python
a             : source.python
              : source.python
=             : keyword.operator.assignment.python, source.python
              : source.python
r             : source.python, storage.type.string.python, string.regexp.quoted.single.python
'             : punctuation.definition.string.begin.python, source.python, string.regexp.quoted.single.python
(             : keyword.operator.lookahead.regexp, punctuation.parenthesis.lookahead.begin.regexp, source.python, string.regexp.quoted.single.python
?=            : keyword.operator.lookahead.regexp, source.python, string.regexp.quoted.single.python
\'            : constant.character.escape.regexp, source.python, string.regexp.quoted.single.python
 for          : source.python, string.regexp.quoted.single.python
              : invalid.illegal.newline.python, source.python, string.regexp.quoted.single.python
a             : source.python
              : source.python
=             : keyword.operator.assignment.python, source.python
              : source.python
r             : source.python, storage.type.string.python, string.regexp.quoted.single.python
"             : punctuation.definition.string.begin.python, source.python, string.regexp.quoted.single.python
(             : keyword.operator.lookahead.regexp, punctuation.parenthesis.lookahead.begin.regexp, source.python, string.regexp.quoted.single.python
?=            : keyword.operator.lookahead.regexp, source.python, string.regexp.quoted.single.python
\"            : constant.character.escape.regexp, source.python, string.regexp.quoted.single.python
 for          : source.python, string.regexp.quoted.single.python
              : invalid.illegal.newline.python, source.python, string.regexp.quoted.single.python
a             : source.python
              : source.python
=             : keyword.operator.assignment.python, source.python
              : source.python
r             : source.python, storage.type.string.python, string.regexp.quoted.single.python
'             : punctuation.definition.string.begin.python, source.python, string.regexp.quoted.single.python
(             : meta.named.regexp, punctuation.parenthesis.named.begin.regexp, source.python, string.regexp.quoted.single.python, support.other.parenthesis.regexp
?P<a>         : entity.name.tag.named.group.regexp, meta.named.regexp, source.python, string.regexp.quoted.single.python
\'            : constant.character.escape.regexp, meta.named.regexp, source.python, string.regexp.quoted.single.python
 for          : meta.named.regexp, source.python, string.regexp.quoted.single.python
              : invalid.illegal.newline.python, source.python, string.regexp.quoted.single.python
a             : source.python
              : source.python
=             : keyword.operator.assignment.python, source.python
              : source.python
r             : source.python, storage.type.string.python, string.regexp.quoted.single.python
"             : punctuation.definition.string.begin.python, source.python, string.regexp.quoted.single.python
(             : meta.named.regexp, punctuation.parenthesis.named.begin.regexp, source.python, string.regexp.quoted.single.python, support.other.parenthesis.regexp
?P<a>         : entity.name.tag.named.group.regexp, meta.named.regexp, source.python, string.regexp.quoted.single.python
\"            : constant.character.escape.regexp, meta.named.regexp, source.python, string.regexp.quoted.single.python
 for          : meta.named.regexp, source.python, string.regexp.quoted.single.python
              : invalid.illegal.newline.python, source.python, string.regexp.quoted.single.python
a             : source.python
              : source.python
=             : keyword.operator.assignment.python, source.python
              : source.python
r             : source.python, storage.type.string.python, string.regexp.quoted.single.python
'             : punctuation.definition.string.begin.python, source.python, string.regexp.quoted.single.python
(             : keyword.operator.lookbehind.negative.regexp, punctuation.parenthesis.lookbehind.begin.regexp, source.python, string.regexp.quoted.single.python
?<!           : keyword.operator.lookbehind.negative.regexp, source.python, string.regexp.quoted.single.python
a             : source.python, string.regexp.quoted.single.python
\'            : constant.character.escape.regexp, source.python, string.regexp.quoted.single.python
 for          : source.python, string.regexp.quoted.single.python
              : invalid.illegal.newline.python, source.python, string.regexp.quoted.single.python
a             : source.python
              : source.python
=             : keyword.operator.assignment.python, source.python
              : source.python
r             : source.python, storage.type.string.python, string.regexp.quoted.single.python
"             : punctuation.definition.string.begin.python, source.python, string.regexp.quoted.single.python
(             : keyword.operator.lookbehind.negative.regexp, punctuation.parenthesis.lookbehind.begin.regexp, source.python, string.regexp.quoted.single.python
?<!           : keyword.operator.lookbehind.negative.regexp, source.python, string.regexp.quoted.single.python
a             : source.python, string.regexp.quoted.single.python
\"            : constant.character.escape.regexp, source.python, string.regexp.quoted.single.python
 for          : source.python, string.regexp.quoted.single.python
              : invalid.illegal.newline.python, source.python, string.regexp.quoted.single.python
return        : keyword.control.flow.python, source.python
              : source.python
some          : source.python
