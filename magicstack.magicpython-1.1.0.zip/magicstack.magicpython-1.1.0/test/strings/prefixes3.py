a = Ur'S T R'
a = UR'S T R'
a = uB'S T R'
a = Ru'S T R'
a = RU'S T R'
a = bR'S T R'
a = Rb'S T R'



a             : source.python
              : source.python
=             : keyword.operator.assignment.python, source.python
              : source.python
Ur            : invalid.deprecated.prefix.python, source.python, string.regexp.quoted.single.python
'             : punctuation.definition.string.begin.python, source.python, string.regexp.quoted.single.python
S T R         : source.python, string.regexp.quoted.single.python
'             : punctuation.definition.string.end.python, source.python, string.regexp.quoted.single.python
a             : source.python
              : source.python
=             : keyword.operator.assignment.python, source.python
              : source.python
UR            : invalid.deprecated.prefix.python, source.python, string.quoted.raw.single.python
'             : punctuation.definition.string.begin.python, source.python, string.quoted.raw.single.python
S T R         : source.python, string.quoted.raw.single.python
'             : punctuation.definition.string.end.python, source.python, string.quoted.raw.single.python
a             : source.python
              : source.python
=             : keyword.operator.assignment.python, source.python
              : source.python
uB            : source.python
'             : punctuation.definition.string.begin.python, source.python, string.quoted.single.python
S T R         : source.python, string.quoted.single.python
'             : punctuation.definition.string.end.python, source.python, string.quoted.single.python
a             : source.python
              : source.python
=             : keyword.operator.assignment.python, source.python
              : source.python
R             : invalid.illegal.prefix.python, source.python, string.quoted.single.python
u             : source.python, storage.type.string.python, string.quoted.single.python
'             : punctuation.definition.string.begin.python, source.python, string.quoted.single.python
S T R         : source.python, string.quoted.single.python
'             : punctuation.definition.string.end.python, source.python, string.quoted.single.python
a             : source.python
              : source.python
=             : keyword.operator.assignment.python, source.python
              : source.python
R             : invalid.illegal.prefix.python, source.python, string.quoted.single.python
U             : source.python, storage.type.string.python, string.quoted.single.python
'             : punctuation.definition.string.begin.python, source.python, string.quoted.single.python
S T R         : source.python, string.quoted.single.python
'             : punctuation.definition.string.end.python, source.python, string.quoted.single.python
a             : source.python
              : source.python
=             : keyword.operator.assignment.python, source.python
              : source.python
bR            : source.python, storage.type.string.python, string.quoted.raw.binary.single.python
'             : punctuation.definition.string.begin.python, source.python, string.quoted.raw.binary.single.python
S T R         : source.python, string.quoted.raw.binary.single.python
'             : punctuation.definition.string.end.python, source.python, string.quoted.raw.binary.single.python
a             : source.python
              : source.python
=             : keyword.operator.assignment.python, source.python
              : source.python
Rb            : source.python, storage.type.string.python, string.quoted.raw.binary.single.python
'             : punctuation.definition.string.begin.python, source.python, string.quoted.raw.binary.single.python
S T R         : source.python, string.quoted.raw.binary.single.python
'             : punctuation.definition.string.end.python, source.python, string.quoted.raw.binary.single.python
