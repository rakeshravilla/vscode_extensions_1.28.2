some.int
some.sum
some.super
some.unicode
some.foo
some.Exception



some          : source.python
.             : punctuation.separator.period.python, source.python
int           : source.python
some          : source.python
.             : punctuation.separator.period.python, source.python
sum           : source.python
some          : source.python
.             : punctuation.separator.period.python, source.python
super         : source.python
some          : source.python
.             : punctuation.separator.period.python, source.python
unicode       : source.python
some          : source.python
.             : punctuation.separator.period.python, source.python
foo           : source.python
some          : source.python
.             : punctuation.separator.period.python, source.python
Exception     : source.python
