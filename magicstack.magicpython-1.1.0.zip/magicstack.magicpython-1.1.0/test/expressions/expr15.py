foofrom.something



foofrom       : source.python
.             : punctuation.separator.period.python, source.python
something     : source.python
