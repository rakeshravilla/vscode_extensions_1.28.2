123l
123L
1_234l



123           : constant.numeric.bin.python, source.python
l             : constant.numeric.bin.python, source.python, storage.type.number.python
123           : constant.numeric.bin.python, source.python
L             : constant.numeric.bin.python, source.python, storage.type.number.python
1_234l        : invalid.illegal.name.python, source.python
