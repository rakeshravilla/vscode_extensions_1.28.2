a = R'$\frac{m_{j \%srightarrow i}(\mathrm{%sgood})}{\su%m{m_{j \rightarrow i}}}$'



a             : source.python
              : source.python
=             : keyword.operator.assignment.python, source.python
              : source.python
R             : source.python, storage.type.string.python, string.quoted.raw.single.python
'             : punctuation.definition.string.begin.python, source.python, string.quoted.raw.single.python
$\frac        : source.python, string.quoted.raw.single.python
{m_{j \       : source.python, string.quoted.raw.single.python
%s            : constant.character.format.placeholder.other.python, meta.format.percent.python, source.python, string.quoted.raw.single.python
rightarrow i}(\mathrm{ : source.python, string.quoted.raw.single.python
%s            : constant.character.format.placeholder.other.python, meta.format.percent.python, source.python, string.quoted.raw.single.python
good})}{\su%m{m_{j \rightarrow i}}}$ : source.python, string.quoted.raw.single.python
'             : punctuation.definition.string.end.python, source.python, string.quoted.raw.single.python
