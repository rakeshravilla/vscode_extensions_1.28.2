'''...'''
...



'''           : punctuation.definition.string.begin.python, source.python, string.quoted.docstring.multi.python
...           : source.python, string.quoted.docstring.multi.python
'''           : punctuation.definition.string.end.python, source.python, string.quoted.docstring.multi.python
...           : constant.other.ellipsis.python, source.python
