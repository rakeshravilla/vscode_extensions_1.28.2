a = self.some_list[1:2]



a             : source.python
              : source.python
=             : keyword.operator.assignment.python, source.python
              : source.python
self          : source.python, variable.language.special.self.python
.             : punctuation.separator.period.python, source.python
some_list     : meta.item-access.python, source.python
[             : meta.item-access.python, punctuation.definition.arguments.begin.python, source.python
1             : constant.numeric.dec.python, meta.item-access.arguments.python, meta.item-access.python, source.python
:             : meta.item-access.arguments.python, meta.item-access.python, punctuation.separator.slice.python, source.python
2             : constant.numeric.dec.python, meta.item-access.arguments.python, meta.item-access.python, source.python
]             : meta.item-access.python, punctuation.definition.arguments.end.python, source.python
