arr2 = [i for i in range(7) if i != 3]



arr2          : source.python
              : source.python
=             : keyword.operator.assignment.python, source.python
              : source.python
[             : punctuation.definition.list.begin.python, source.python
i             : source.python
              : source.python
for           : keyword.control.flow.python, source.python
              : source.python
i             : source.python
              : source.python
in            : keyword.operator.logical.python, source.python
              : source.python
range         : meta.function-call.python, source.python, support.function.builtin.python
(             : meta.function-call.python, punctuation.definition.arguments.begin.python, source.python
7             : constant.numeric.dec.python, meta.function-call.arguments.python, meta.function-call.python, source.python
)             : meta.function-call.python, punctuation.definition.arguments.end.python, source.python
              : source.python
if            : keyword.control.flow.python, source.python
              : source.python
i             : source.python
              : source.python
!=            : keyword.operator.comparison.python, source.python
              : source.python
3             : constant.numeric.dec.python, source.python
]             : punctuation.definition.list.end.python, source.python
