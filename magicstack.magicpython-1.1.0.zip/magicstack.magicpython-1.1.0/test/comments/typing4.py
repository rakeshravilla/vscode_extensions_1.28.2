x = None # type: List[str, a]
y = None # type: Dict[int, Any] # int



x             : source.python
              : source.python
=             : keyword.operator.assignment.python, source.python
              : source.python
None          : constant.language.python, source.python
              : source.python
#             : comment.line.number-sign.python, meta.typehint.comment.python, source.python
type:         : comment.line.number-sign.python, comment.typehint.directive.notation.python, meta.typehint.comment.python, source.python
              : comment.line.number-sign.python, meta.typehint.comment.python, source.python
List          : comment.line.number-sign.python, comment.typehint.type.notation.python, meta.typehint.comment.python, source.python
[             : comment.line.number-sign.python, comment.typehint.punctuation.notation.python, meta.typehint.comment.python, source.python
str           : comment.line.number-sign.python, comment.typehint.type.notation.python, meta.typehint.comment.python, source.python
,             : comment.line.number-sign.python, comment.typehint.punctuation.notation.python, meta.typehint.comment.python, source.python
              : comment.line.number-sign.python, meta.typehint.comment.python, source.python
a             : comment.line.number-sign.python, comment.typehint.variable.notation.python, meta.typehint.comment.python, source.python
]             : comment.line.number-sign.python, comment.typehint.punctuation.notation.python, meta.typehint.comment.python, source.python
y             : source.python
              : source.python
=             : keyword.operator.assignment.python, source.python
              : source.python
None          : constant.language.python, source.python
              : source.python
#             : comment.line.number-sign.python, meta.typehint.comment.python, source.python
type:         : comment.line.number-sign.python, comment.typehint.directive.notation.python, meta.typehint.comment.python, source.python
              : comment.line.number-sign.python, meta.typehint.comment.python, source.python
Dict          : comment.line.number-sign.python, comment.typehint.type.notation.python, meta.typehint.comment.python, source.python
[             : comment.line.number-sign.python, comment.typehint.punctuation.notation.python, meta.typehint.comment.python, source.python
int           : comment.line.number-sign.python, comment.typehint.type.notation.python, meta.typehint.comment.python, source.python
,             : comment.line.number-sign.python, comment.typehint.punctuation.notation.python, meta.typehint.comment.python, source.python
              : comment.line.number-sign.python, meta.typehint.comment.python, source.python
Any           : comment.line.number-sign.python, comment.typehint.type.notation.python, meta.typehint.comment.python, source.python
]             : comment.line.number-sign.python, comment.typehint.punctuation.notation.python, meta.typehint.comment.python, source.python
              : comment.line.number-sign.python, meta.typehint.comment.python, source.python
#             : comment.line.number-sign.python, punctuation.definition.comment.python, source.python
 int          : comment.line.number-sign.python, source.python
