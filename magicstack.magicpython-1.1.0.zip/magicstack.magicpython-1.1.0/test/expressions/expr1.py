~a + b @ c ^ d // e % f & e and not g or h


~             : keyword.operator.bitwise.python, source.python
a             : source.python
              : source.python
+             : keyword.operator.arithmetic.python, source.python
              : source.python
b             : source.python
              : source.python
@             : keyword.operator.arithmetic.python, source.python
              : source.python
c             : source.python
              : source.python
^             : keyword.operator.bitwise.python, source.python
              : source.python
d             : source.python
              : source.python
//            : keyword.operator.arithmetic.python, source.python
              : source.python
e             : source.python
              : source.python
%             : keyword.operator.arithmetic.python, source.python
              : source.python
f             : source.python
              : source.python
&             : keyword.operator.bitwise.python, source.python
              : source.python
e             : source.python
              : source.python
and           : keyword.operator.logical.python, source.python
              : source.python
not           : keyword.operator.logical.python, source.python
              : source.python
g             : source.python
              : source.python
or            : keyword.operator.logical.python, source.python
              : source.python
h             : source.python
