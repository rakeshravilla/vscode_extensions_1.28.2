# type: ignore  # test
# type:  ignore
# type:ignore
#type:ignore
# type: ignore 1
# type: 1 ignore
# type : ignore
##type: ignore
#.type: ignore



#             : comment.line.number-sign.python, meta.typehint.comment.python, source.python
type:         : comment.line.number-sign.python, comment.typehint.directive.notation.python, meta.typehint.comment.python, source.python
              : comment.line.number-sign.python, meta.typehint.comment.python, source.python
ignore        : comment.line.number-sign.python, comment.typehint.ignore.notation.python, meta.typehint.comment.python, source.python
              : comment.line.number-sign.python, meta.typehint.comment.python, source.python
#             : comment.line.number-sign.python, punctuation.definition.comment.python, source.python
 test         : comment.line.number-sign.python, source.python
#             : comment.line.number-sign.python, meta.typehint.comment.python, source.python
type:         : comment.line.number-sign.python, comment.typehint.directive.notation.python, meta.typehint.comment.python, source.python
              : comment.line.number-sign.python, meta.typehint.comment.python, source.python
ignore        : comment.line.number-sign.python, comment.typehint.ignore.notation.python, meta.typehint.comment.python, source.python
#             : comment.line.number-sign.python, meta.typehint.comment.python, source.python
type:         : comment.line.number-sign.python, comment.typehint.directive.notation.python, meta.typehint.comment.python, source.python
ignore        : comment.line.number-sign.python, comment.typehint.ignore.notation.python, meta.typehint.comment.python, source.python
#             : comment.line.number-sign.python, meta.typehint.comment.python, source.python
type:         : comment.line.number-sign.python, comment.typehint.directive.notation.python, meta.typehint.comment.python, source.python
ignore        : comment.line.number-sign.python, comment.typehint.ignore.notation.python, meta.typehint.comment.python, source.python
#             : comment.line.number-sign.python, meta.typehint.comment.python, source.python
type:         : comment.line.number-sign.python, comment.typehint.directive.notation.python, meta.typehint.comment.python, source.python
              : comment.line.number-sign.python, meta.typehint.comment.python, source.python
ignore        : comment.line.number-sign.python, comment.typehint.variable.notation.python, meta.typehint.comment.python, source.python
 1            : comment.line.number-sign.python, meta.typehint.comment.python, source.python
#             : comment.line.number-sign.python, meta.typehint.comment.python, source.python
type:         : comment.line.number-sign.python, comment.typehint.directive.notation.python, meta.typehint.comment.python, source.python
              : comment.line.number-sign.python, meta.typehint.comment.python, source.python
1             : comment.line.number-sign.python, meta.typehint.comment.python, source.python
ignore        : comment.line.number-sign.python, comment.typehint.variable.notation.python, meta.typehint.comment.python, source.python
#             : comment.line.number-sign.python, punctuation.definition.comment.python, source.python
 type : ignore : comment.line.number-sign.python, source.python
#             : comment.line.number-sign.python, punctuation.definition.comment.python, source.python
#type: ignore : comment.line.number-sign.python, source.python
#             : comment.line.number-sign.python, punctuation.definition.comment.python, source.python
.type: ignore : comment.line.number-sign.python, source.python
