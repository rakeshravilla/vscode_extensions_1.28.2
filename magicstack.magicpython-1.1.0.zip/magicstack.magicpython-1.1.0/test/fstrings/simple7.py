f'abc \ efg'




f             : meta.fstring.python, source.python, storage.type.string.python, string.interpolated.python, string.quoted.single.python
'             : meta.fstring.python, punctuation.definition.string.begin.python, source.python, string.interpolated.python, string.quoted.single.python
abc           : meta.fstring.python, source.python, string.interpolated.python, string.quoted.single.python
\ efg         : meta.fstring.python, source.python, string.interpolated.python, string.quoted.single.python
'             : meta.fstring.python, punctuation.definition.string.end.python, source.python, string.interpolated.python, string.quoted.single.python
