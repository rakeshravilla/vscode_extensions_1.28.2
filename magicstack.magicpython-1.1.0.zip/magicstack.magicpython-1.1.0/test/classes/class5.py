class Foo(Exception, MyObj): pass



class         : meta.class.python, source.python, storage.type.class.python
              : meta.class.python, source.python
Foo           : entity.name.type.class.python, meta.class.python, source.python
(             : meta.class.inheritance.python, meta.class.python, punctuation.definition.inheritance.begin.python, source.python
Exception     : meta.class.inheritance.python, meta.class.python, source.python, support.type.exception.python
,             : meta.class.inheritance.python, meta.class.python, punctuation.separator.inheritance.python, source.python
              : meta.class.inheritance.python, meta.class.python, source.python
MyObj         : entity.other.inherited-class.python, meta.class.inheritance.python, meta.class.python, source.python
)             : meta.class.inheritance.python, meta.class.python, punctuation.definition.inheritance.end.python, source.python
:             : meta.class.python, punctuation.section.class.begin.python, source.python
              : source.python
pass          : keyword.control.flow.python, source.python
