r'''Module docstring

    {{ %d simple \\ string \
    foo \' \" \a \b \c \f \n \r \t \v \5 \55 \555 \05 \005

    multiline "unicode" string \
    \xf1 \u1234aaaa \U1234aaaa
    \N{BLACK SPADE SUIT}
    >>> aaa
'''

R'''Module docstring

    {{ %d simple \\ string \
    foo \' \" \a \b \c \f \n \r \t \v \5 \55 \555 \05 \005

    multiline "unicode" string \
    \xf1 \u1234aaaa \U1234aaaa
    \N{BLACK SPADE SUIT}
    >>> aaa
'''



r             : source.python, storage.type.string.python, string.quoted.docstring.raw.multi.python
'''           : punctuation.definition.string.begin.python, source.python, string.quoted.docstring.raw.multi.python
Module docstring : source.python, string.quoted.docstring.raw.multi.python
              : source.python, string.quoted.docstring.raw.multi.python
    {{ %d simple  : source.python, string.quoted.docstring.raw.multi.python
\\            : source.python, string.quoted.docstring.raw.multi.python
 string       : source.python, string.quoted.docstring.raw.multi.python
\             : source.python, string.quoted.docstring.raw.multi.python
    foo       : source.python, string.quoted.docstring.raw.multi.python
\'            : source.python, string.quoted.docstring.raw.multi.python
              : source.python, string.quoted.docstring.raw.multi.python
\"            : source.python, string.quoted.docstring.raw.multi.python
 \a \b \c \f \n \r \t \v \5 \55 \555 \05 \005 : source.python, string.quoted.docstring.raw.multi.python
              : source.python, string.quoted.docstring.raw.multi.python
    multiline "unicode" string  : source.python, string.quoted.docstring.raw.multi.python
\             : source.python, string.quoted.docstring.raw.multi.python
    \xf1 \u1234aaaa \U1234aaaa : source.python, string.quoted.docstring.raw.multi.python
    \N{BLACK SPADE SUIT} : source.python, string.quoted.docstring.raw.multi.python
              : source.python, string.quoted.docstring.raw.multi.python
>>>           : keyword.control.flow.python, source.python, string.quoted.docstring.raw.multi.python
aaa           : source.python, string.quoted.docstring.raw.multi.python
'''           : punctuation.definition.string.end.python, source.python, string.quoted.docstring.raw.multi.python
              : source.python
R             : source.python, storage.type.string.python, string.quoted.docstring.raw.multi.python
'''           : punctuation.definition.string.begin.python, source.python, string.quoted.docstring.raw.multi.python
Module docstring : source.python, string.quoted.docstring.raw.multi.python
              : source.python, string.quoted.docstring.raw.multi.python
    {{ %d simple  : source.python, string.quoted.docstring.raw.multi.python
\\            : source.python, string.quoted.docstring.raw.multi.python
 string       : source.python, string.quoted.docstring.raw.multi.python
\             : source.python, string.quoted.docstring.raw.multi.python
    foo       : source.python, string.quoted.docstring.raw.multi.python
\'            : source.python, string.quoted.docstring.raw.multi.python
              : source.python, string.quoted.docstring.raw.multi.python
\"            : source.python, string.quoted.docstring.raw.multi.python
 \a \b \c \f \n \r \t \v \5 \55 \555 \05 \005 : source.python, string.quoted.docstring.raw.multi.python
              : source.python, string.quoted.docstring.raw.multi.python
    multiline "unicode" string  : source.python, string.quoted.docstring.raw.multi.python
\             : source.python, string.quoted.docstring.raw.multi.python
    \xf1 \u1234aaaa \U1234aaaa : source.python, string.quoted.docstring.raw.multi.python
    \N{BLACK SPADE SUIT} : source.python, string.quoted.docstring.raw.multi.python
              : source.python, string.quoted.docstring.raw.multi.python
>>>           : keyword.control.flow.python, source.python, string.quoted.docstring.raw.multi.python
aaa           : source.python, string.quoted.docstring.raw.multi.python
'''           : punctuation.definition.string.end.python, source.python, string.quoted.docstring.raw.multi.python
