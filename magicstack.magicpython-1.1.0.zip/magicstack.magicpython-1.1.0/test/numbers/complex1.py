3.14j
10.j
10j
.001j
1e100j
3.14e-10j



3.14          : constant.numeric.float.python, source.python
j             : constant.numeric.float.python, source.python, storage.type.imaginary.number.python
10.           : constant.numeric.float.python, source.python
j             : constant.numeric.float.python, source.python, storage.type.imaginary.number.python
10            : constant.numeric.dec.python, source.python
j             : constant.numeric.dec.python, source.python, storage.type.imaginary.number.python
.001          : constant.numeric.float.python, source.python
j             : constant.numeric.float.python, source.python, storage.type.imaginary.number.python
1e100         : constant.numeric.float.python, source.python
j             : constant.numeric.float.python, source.python, storage.type.imaginary.number.python
3.14e-10      : constant.numeric.float.python, source.python
j             : constant.numeric.float.python, source.python, storage.type.imaginary.number.python
