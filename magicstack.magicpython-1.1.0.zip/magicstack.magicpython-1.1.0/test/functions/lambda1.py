# That's how we want it:
lll(lambda)



#             : comment.line.number-sign.python, punctuation.definition.comment.python, source.python
 That's how we want it: : comment.line.number-sign.python, source.python
lll           : meta.function-call.generic.python, meta.function-call.python, source.python
(             : meta.function-call.python, punctuation.definition.arguments.begin.python, source.python
lambda        : meta.function-call.arguments.python, meta.function-call.python, source.python, storage.type.function.lambda.python
)             : meta.function-call.python, punctuation.definition.arguments.end.python, source.python
