self.assertEqual(f'{10:#{3 != {4:5} and width}x}', '       0xa')




self          : source.python, variable.language.special.self.python
.             : punctuation.separator.period.python, source.python
assertEqual   : meta.function-call.generic.python, meta.function-call.python, source.python
(             : meta.function-call.python, punctuation.definition.arguments.begin.python, source.python
f             : meta.fstring.python, meta.function-call.arguments.python, meta.function-call.python, source.python, storage.type.string.python, string.interpolated.python, string.quoted.single.python
'             : meta.fstring.python, meta.function-call.arguments.python, meta.function-call.python, punctuation.definition.string.begin.python, source.python, string.interpolated.python, string.quoted.single.python
{             : constant.character.format.placeholder.other.python, meta.fstring.python, meta.function-call.arguments.python, meta.function-call.python, source.python
10            : constant.numeric.dec.python, meta.fstring.python, meta.function-call.arguments.python, meta.function-call.python, source.python
:             : meta.fstring.python, meta.function-call.arguments.python, meta.function-call.python, source.python, storage.type.format.python
#             : meta.fstring.python, meta.function-call.arguments.python, meta.function-call.python, source.python, storage.type.format.python
{             : constant.character.format.placeholder.other.python, meta.fstring.python, meta.function-call.arguments.python, meta.function-call.python, source.python
3             : constant.numeric.dec.python, meta.fstring.python, meta.function-call.arguments.python, meta.function-call.python, source.python
              : meta.fstring.python, meta.function-call.arguments.python, meta.function-call.python, source.python
!=            : keyword.operator.comparison.python, meta.fstring.python, meta.function-call.arguments.python, meta.function-call.python, source.python
              : meta.fstring.python, meta.function-call.arguments.python, meta.function-call.python, source.python
{             : meta.fstring.python, meta.function-call.arguments.python, meta.function-call.python, punctuation.definition.dict.begin.python, source.python
4             : constant.numeric.dec.python, meta.fstring.python, meta.function-call.arguments.python, meta.function-call.python, source.python
:             : meta.fstring.python, meta.function-call.arguments.python, meta.function-call.python, punctuation.separator.dict.python, source.python
5             : constant.numeric.dec.python, meta.fstring.python, meta.function-call.arguments.python, meta.function-call.python, source.python
}             : meta.fstring.python, meta.function-call.arguments.python, meta.function-call.python, punctuation.definition.dict.end.python, source.python
              : meta.fstring.python, meta.function-call.arguments.python, meta.function-call.python, source.python
and           : keyword.operator.logical.python, meta.fstring.python, meta.function-call.arguments.python, meta.function-call.python, source.python
              : meta.fstring.python, meta.function-call.arguments.python, meta.function-call.python, source.python
width         : meta.fstring.python, meta.function-call.arguments.python, meta.function-call.python, source.python
}             : constant.character.format.placeholder.other.python, meta.fstring.python, meta.function-call.arguments.python, meta.function-call.python, source.python
x             : meta.fstring.python, meta.function-call.arguments.python, meta.function-call.python, source.python, storage.type.format.python
}             : constant.character.format.placeholder.other.python, meta.fstring.python, meta.function-call.arguments.python, meta.function-call.python, source.python
'             : meta.fstring.python, meta.function-call.arguments.python, meta.function-call.python, punctuation.definition.string.end.python, source.python, string.interpolated.python, string.quoted.single.python
,             : meta.function-call.arguments.python, meta.function-call.python, punctuation.separator.arguments.python, source.python
              : meta.function-call.arguments.python, meta.function-call.python, source.python
'             : meta.function-call.arguments.python, meta.function-call.python, punctuation.definition.string.begin.python, source.python, string.quoted.single.python
       0xa    : meta.function-call.arguments.python, meta.function-call.python, source.python, string.quoted.single.python
'             : meta.function-call.arguments.python, meta.function-call.python, punctuation.definition.string.end.python, source.python, string.quoted.single.python
)             : meta.function-call.python, punctuation.definition.arguments.end.python, source.python
