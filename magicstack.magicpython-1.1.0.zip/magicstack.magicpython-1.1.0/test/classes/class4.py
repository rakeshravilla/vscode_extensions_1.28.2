class Exception: pass




class         : meta.class.python, source.python, storage.type.class.python
              : meta.class.python, source.python
Exception     : meta.class.python, source.python, support.type.exception.python
:             : meta.class.python, punctuation.section.class.begin.python, source.python
              : source.python
pass          : keyword.control.flow.python, source.python
