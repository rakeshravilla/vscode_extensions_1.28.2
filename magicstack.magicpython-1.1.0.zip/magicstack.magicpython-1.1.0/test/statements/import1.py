from ...foo import bar as spam, baz
import time as ham, datetime



from          : keyword.control.import.python, source.python
              : source.python
...           : punctuation.separator.period.python, source.python
foo           : source.python
              : source.python
import        : keyword.control.import.python, source.python
              : source.python
bar           : source.python
              : source.python
as            : keyword.control.flow.python, source.python
              : source.python
spam          : source.python
,             : punctuation.separator.element.python, source.python
              : source.python
baz           : source.python
import        : keyword.control.import.python, source.python
              : source.python
time          : source.python
              : source.python
as            : keyword.control.flow.python, source.python
              : source.python
ham           : source.python
,             : punctuation.separator.element.python, source.python
              : source.python
datetime      : source.python
