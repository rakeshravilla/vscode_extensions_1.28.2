foo(djsgfjs==123)



foo           : meta.function-call.generic.python, meta.function-call.python, source.python
(             : meta.function-call.python, punctuation.definition.arguments.begin.python, source.python
djsgfjs       : meta.function-call.arguments.python, meta.function-call.python, source.python
==            : keyword.operator.comparison.python, meta.function-call.arguments.python, meta.function-call.python, source.python
123           : constant.numeric.dec.python, meta.function-call.arguments.python, meta.function-call.python, source.python
)             : meta.function-call.python, punctuation.definition.arguments.end.python, source.python
