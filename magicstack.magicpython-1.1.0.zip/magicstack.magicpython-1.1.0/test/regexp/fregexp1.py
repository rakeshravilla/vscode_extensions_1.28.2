a = fr'[a-z]'
a = Fr'[a-z]'
a = rf'[a-z]'
a = rF'[a-z]'




a             : source.python
              : source.python
=             : keyword.operator.assignment.python, source.python
              : source.python
fr            : source.python, storage.type.string.python, string.interpolated.python, string.regexp.quoted.single.python
'             : punctuation.definition.string.begin.python, source.python, string.interpolated.python, string.regexp.quoted.single.python
[             : constant.other.set.regexp, meta.character.set.regexp, punctuation.character.set.begin.regexp, source.python, string.interpolated.python, string.regexp.quoted.single.python
a             : constant.character.set.regexp, meta.character.set.regexp, source.python, string.interpolated.python, string.regexp.quoted.single.python
-             : constant.character.set.regexp, meta.character.set.regexp, source.python, string.interpolated.python, string.regexp.quoted.single.python
z             : constant.character.set.regexp, meta.character.set.regexp, source.python, string.interpolated.python, string.regexp.quoted.single.python
]             : constant.other.set.regexp, meta.character.set.regexp, punctuation.character.set.end.regexp, source.python, string.interpolated.python, string.regexp.quoted.single.python
'             : punctuation.definition.string.end.python, source.python, string.interpolated.python, string.regexp.quoted.single.python
a             : source.python
              : source.python
=             : keyword.operator.assignment.python, source.python
              : source.python
Fr            : source.python, storage.type.string.python, string.interpolated.python, string.regexp.quoted.single.python
'             : punctuation.definition.string.begin.python, source.python, string.interpolated.python, string.regexp.quoted.single.python
[             : constant.other.set.regexp, meta.character.set.regexp, punctuation.character.set.begin.regexp, source.python, string.interpolated.python, string.regexp.quoted.single.python
a             : constant.character.set.regexp, meta.character.set.regexp, source.python, string.interpolated.python, string.regexp.quoted.single.python
-             : constant.character.set.regexp, meta.character.set.regexp, source.python, string.interpolated.python, string.regexp.quoted.single.python
z             : constant.character.set.regexp, meta.character.set.regexp, source.python, string.interpolated.python, string.regexp.quoted.single.python
]             : constant.other.set.regexp, meta.character.set.regexp, punctuation.character.set.end.regexp, source.python, string.interpolated.python, string.regexp.quoted.single.python
'             : punctuation.definition.string.end.python, source.python, string.interpolated.python, string.regexp.quoted.single.python
a             : source.python
              : source.python
=             : keyword.operator.assignment.python, source.python
              : source.python
rf            : source.python, storage.type.string.python, string.interpolated.python, string.regexp.quoted.single.python
'             : punctuation.definition.string.begin.python, source.python, string.interpolated.python, string.regexp.quoted.single.python
[             : constant.other.set.regexp, meta.character.set.regexp, punctuation.character.set.begin.regexp, source.python, string.interpolated.python, string.regexp.quoted.single.python
a             : constant.character.set.regexp, meta.character.set.regexp, source.python, string.interpolated.python, string.regexp.quoted.single.python
-             : constant.character.set.regexp, meta.character.set.regexp, source.python, string.interpolated.python, string.regexp.quoted.single.python
z             : constant.character.set.regexp, meta.character.set.regexp, source.python, string.interpolated.python, string.regexp.quoted.single.python
]             : constant.other.set.regexp, meta.character.set.regexp, punctuation.character.set.end.regexp, source.python, string.interpolated.python, string.regexp.quoted.single.python
'             : punctuation.definition.string.end.python, source.python, string.interpolated.python, string.regexp.quoted.single.python
a             : source.python
              : source.python
=             : keyword.operator.assignment.python, source.python
              : source.python
rF            : source.python, storage.type.string.python, string.interpolated.python, string.regexp.quoted.single.python
'             : punctuation.definition.string.begin.python, source.python, string.interpolated.python, string.regexp.quoted.single.python
[             : constant.other.set.regexp, meta.character.set.regexp, punctuation.character.set.begin.regexp, source.python, string.interpolated.python, string.regexp.quoted.single.python
a             : constant.character.set.regexp, meta.character.set.regexp, source.python, string.interpolated.python, string.regexp.quoted.single.python
-             : constant.character.set.regexp, meta.character.set.regexp, source.python, string.interpolated.python, string.regexp.quoted.single.python
z             : constant.character.set.regexp, meta.character.set.regexp, source.python, string.interpolated.python, string.regexp.quoted.single.python
]             : constant.other.set.regexp, meta.character.set.regexp, punctuation.character.set.end.regexp, source.python, string.interpolated.python, string.regexp.quoted.single.python
'             : punctuation.definition.string.end.python, source.python, string.interpolated.python, string.regexp.quoted.single.python
