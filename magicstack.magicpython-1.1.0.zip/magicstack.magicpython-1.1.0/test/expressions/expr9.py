yield  from a
yield a



yield  from   : keyword.control.flow.python, source.python
              : source.python
a             : source.python
yield         : keyword.control.flow.python, source.python
              : source.python
a             : source.python
