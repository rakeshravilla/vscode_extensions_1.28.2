__post_init__
def __class_getitem__(): pass
__mro_entries__



__post_init__ : source.python, support.variable.magic.python
def           : meta.function.python, source.python, storage.type.function.python
              : meta.function.python, source.python
__class_getitem__ : meta.function.python, source.python, support.variable.magic.python
(             : meta.function.parameters.python, meta.function.python, punctuation.definition.parameters.begin.python, source.python
)             : meta.function.parameters.python, meta.function.python, punctuation.definition.parameters.end.python, source.python
:             : meta.function.python, punctuation.section.function.begin.python, source.python
              : source.python
pass          : keyword.control.flow.python, source.python
__mro_entries__ : source.python, support.variable.magic.python
