class Foo:
    """TEST"""

class Foo:
    r"""TEST"""

class Foo:
    R"""TEST"""

class Foo:
    u"""TEST"""

class Foo:
    U"""TEST"""

class Foo:
    b"""TEST"""

class Foo:
    B"""TEST"""




class         : meta.class.python, source.python, storage.type.class.python
              : meta.class.python, source.python
Foo           : entity.name.type.class.python, meta.class.python, source.python
:             : meta.class.python, punctuation.section.class.begin.python, source.python
              : source.python
"""           : punctuation.definition.string.begin.python, source.python, string.quoted.docstring.multi.python
TEST          : source.python, string.quoted.docstring.multi.python
"""           : punctuation.definition.string.end.python, source.python, string.quoted.docstring.multi.python
              : source.python
class         : meta.class.python, source.python, storage.type.class.python
              : meta.class.python, source.python
Foo           : entity.name.type.class.python, meta.class.python, source.python
:             : meta.class.python, punctuation.section.class.begin.python, source.python
              : source.python
r             : source.python, storage.type.string.python, string.quoted.docstring.raw.multi.python
"""           : punctuation.definition.string.begin.python, source.python, string.quoted.docstring.raw.multi.python
TEST          : source.python, string.quoted.docstring.raw.multi.python
"""           : punctuation.definition.string.end.python, source.python, string.quoted.docstring.raw.multi.python
              : source.python
class         : meta.class.python, source.python, storage.type.class.python
              : meta.class.python, source.python
Foo           : entity.name.type.class.python, meta.class.python, source.python
:             : meta.class.python, punctuation.section.class.begin.python, source.python
              : source.python
R             : source.python, storage.type.string.python, string.quoted.docstring.raw.multi.python
"""           : punctuation.definition.string.begin.python, source.python, string.quoted.docstring.raw.multi.python
TEST          : source.python, string.quoted.docstring.raw.multi.python
"""           : punctuation.definition.string.end.python, source.python, string.quoted.docstring.raw.multi.python
              : source.python
class         : meta.class.python, source.python, storage.type.class.python
              : meta.class.python, source.python
Foo           : entity.name.type.class.python, meta.class.python, source.python
:             : meta.class.python, punctuation.section.class.begin.python, source.python
              : source.python
u             : source.python, storage.type.string.python, string.quoted.multi.python
"""           : punctuation.definition.string.begin.python, source.python, string.quoted.multi.python
TEST          : source.python, string.quoted.multi.python
"""           : punctuation.definition.string.end.python, source.python, string.quoted.multi.python
              : source.python
class         : meta.class.python, source.python, storage.type.class.python
              : meta.class.python, source.python
Foo           : entity.name.type.class.python, meta.class.python, source.python
:             : meta.class.python, punctuation.section.class.begin.python, source.python
              : source.python
U             : source.python, storage.type.string.python, string.quoted.multi.python
"""           : punctuation.definition.string.begin.python, source.python, string.quoted.multi.python
TEST          : source.python, string.quoted.multi.python
"""           : punctuation.definition.string.end.python, source.python, string.quoted.multi.python
              : source.python
class         : meta.class.python, source.python, storage.type.class.python
              : meta.class.python, source.python
Foo           : entity.name.type.class.python, meta.class.python, source.python
:             : meta.class.python, punctuation.section.class.begin.python, source.python
              : source.python
b             : source.python, storage.type.string.python, string.quoted.binary.multi.python
"""           : punctuation.definition.string.begin.python, source.python, string.quoted.binary.multi.python
TEST          : source.python, string.quoted.binary.multi.python
"""           : punctuation.definition.string.end.python, source.python, string.quoted.binary.multi.python
              : source.python
class         : meta.class.python, source.python, storage.type.class.python
              : meta.class.python, source.python
Foo           : entity.name.type.class.python, meta.class.python, source.python
:             : meta.class.python, punctuation.section.class.begin.python, source.python
              : source.python
B             : source.python, storage.type.string.python, string.quoted.binary.multi.python
"""           : punctuation.definition.string.begin.python, source.python, string.quoted.binary.multi.python
TEST          : source.python, string.quoted.binary.multi.python
"""           : punctuation.definition.string.end.python, source.python, string.quoted.binary.multi.python
