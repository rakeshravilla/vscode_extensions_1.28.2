__version__ __doc__ __file__
__author__



__version__   : source.python, support.variable.magic.python
              : source.python
__doc__       : source.python, support.variable.magic.python
              : source.python
__file__      : source.python, support.variable.magic.python
__author__    : source.python
