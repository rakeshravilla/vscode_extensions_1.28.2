@a.b.c.None.z
def foo(): pass



@             : entity.name.function.decorator.python, meta.function.decorator.python, punctuation.definition.decorator.python, source.python
a             : entity.name.function.decorator.python, meta.function.decorator.python, source.python
.             : entity.name.function.decorator.python, meta.function.decorator.python, punctuation.separator.period.python, source.python
b             : entity.name.function.decorator.python, meta.function.decorator.python, source.python
.             : entity.name.function.decorator.python, meta.function.decorator.python, punctuation.separator.period.python, source.python
c             : entity.name.function.decorator.python, meta.function.decorator.python, source.python
.             : entity.name.function.decorator.python, meta.function.decorator.python, punctuation.separator.period.python, source.python
None          : keyword.illegal.name.python, meta.function.decorator.python, source.python
.             : entity.name.function.decorator.python, meta.function.decorator.python, punctuation.separator.period.python, source.python
z             : entity.name.function.decorator.python, meta.function.decorator.python, source.python
def           : meta.function.python, source.python, storage.type.function.python
              : meta.function.python, source.python
foo           : entity.name.function.python, meta.function.python, source.python
(             : meta.function.parameters.python, meta.function.python, punctuation.definition.parameters.begin.python, source.python
)             : meta.function.parameters.python, meta.function.python, punctuation.definition.parameters.end.python, source.python
:             : meta.function.python, punctuation.section.function.begin.python, source.python
              : source.python
pass          : keyword.control.flow.python, source.python
