fr'some {obj}'
Fr'some {obj}'
fR'some {obj}'
FR'some {obj}'




fr            : source.python, storage.type.string.python, string.interpolated.python, string.regexp.quoted.single.python
'             : punctuation.definition.string.begin.python, source.python, string.interpolated.python, string.regexp.quoted.single.python
some          : source.python, string.interpolated.python, string.regexp.quoted.single.python
{obj}         : source.python, string.interpolated.python, string.regexp.quoted.single.python
'             : punctuation.definition.string.end.python, source.python, string.interpolated.python, string.regexp.quoted.single.python
Fr            : source.python, storage.type.string.python, string.interpolated.python, string.regexp.quoted.single.python
'             : punctuation.definition.string.begin.python, source.python, string.interpolated.python, string.regexp.quoted.single.python
some          : source.python, string.interpolated.python, string.regexp.quoted.single.python
{obj}         : source.python, string.interpolated.python, string.regexp.quoted.single.python
'             : punctuation.definition.string.end.python, source.python, string.interpolated.python, string.regexp.quoted.single.python
fR            : meta.fstring.python, source.python, storage.type.string.python, string.interpolated.python, string.quoted.raw.single.python
'             : meta.fstring.python, punctuation.definition.string.begin.python, source.python, string.quoted.raw.single.python
some          : meta.fstring.python, source.python, string.interpolated.python, string.quoted.raw.single.python
{             : constant.character.format.placeholder.other.python, meta.fstring.python, source.python
obj           : meta.fstring.python, source.python
}             : constant.character.format.placeholder.other.python, meta.fstring.python, source.python
'             : meta.fstring.python, punctuation.definition.string.end.python, source.python, string.interpolated.python, string.quoted.raw.single.python
FR            : meta.fstring.python, source.python, storage.type.string.python, string.interpolated.python, string.quoted.raw.single.python
'             : meta.fstring.python, punctuation.definition.string.begin.python, source.python, string.quoted.raw.single.python
some          : meta.fstring.python, source.python, string.interpolated.python, string.quoted.raw.single.python
{             : constant.character.format.placeholder.other.python, meta.fstring.python, source.python
obj           : meta.fstring.python, source.python
}             : constant.character.format.placeholder.other.python, meta.fstring.python, source.python
'             : meta.fstring.python, punctuation.definition.string.end.python, source.python, string.interpolated.python, string.quoted.raw.single.python
