a = R'$\frac{m_{j \rightarrow i}(\mathrm{good})}{\sum{m_{j \rightarrow i}}}$'



a             : source.python
              : source.python
=             : keyword.operator.assignment.python, source.python
              : source.python
R             : source.python, storage.type.string.python, string.quoted.raw.single.python
'             : punctuation.definition.string.begin.python, source.python, string.quoted.raw.single.python
$\frac        : source.python, string.quoted.raw.single.python
{m_{j \rightarrow i}(\mathrm{good})}{\sum{m_{j \rightarrow i}}}$ : source.python, string.quoted.raw.single.python
'             : punctuation.definition.string.end.python, source.python, string.quoted.raw.single.python
