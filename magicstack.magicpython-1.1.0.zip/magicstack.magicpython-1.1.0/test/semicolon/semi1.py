a;
;
a=1; b



a             : source.python
;             : invalid.deprecated.semicolon.python, source.python
;             : invalid.deprecated.semicolon.python, source.python
a             : source.python
=             : keyword.operator.assignment.python, source.python
1             : constant.numeric.dec.python, source.python
;             : source.python
b             : source.python
