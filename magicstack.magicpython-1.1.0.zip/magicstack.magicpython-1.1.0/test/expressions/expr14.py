a <> b



a             : source.python
              : source.python
<             : keyword.operator.comparison.python, source.python
>             : keyword.operator.comparison.python, source.python
              : source.python
b             : source.python
