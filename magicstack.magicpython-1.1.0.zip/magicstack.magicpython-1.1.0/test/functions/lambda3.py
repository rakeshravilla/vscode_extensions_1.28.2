anon = lambda lambda: 42



anon          : source.python
              : source.python
=             : keyword.operator.assignment.python, source.python
              : source.python
lambda        : meta.lambda-function.python, source.python, storage.type.function.lambda.python
              : meta.function.lambda.parameters.python, meta.lambda-function.python, source.python
lambda        : meta.function.lambda.parameters.python, meta.lambda-function.python, source.python, storage.type.function.lambda.python
:             : meta.lambda-function.python, punctuation.section.function.lambda.begin.python, source.python
              : source.python
42            : constant.numeric.dec.python, source.python
