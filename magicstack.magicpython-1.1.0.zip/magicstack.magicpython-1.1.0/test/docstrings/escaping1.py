'''Module docstring

    {{ %d simple \\ string \
    foo \' \" \a \b \c \f \n \r \t \v \5 \55 \555 \05 \005

    multiline "unicode" string \
    \xf1 \u1234aaaa \U1234aaaa
    \N{BLACK SPADE SUIT}
'''



'''           : punctuation.definition.string.begin.python, source.python, string.quoted.docstring.multi.python
Module docstring : source.python, string.quoted.docstring.multi.python
              : source.python, string.quoted.docstring.multi.python
    {{ %d simple  : source.python, string.quoted.docstring.multi.python
\\            : constant.character.escape.python, source.python, string.quoted.docstring.multi.python
 string       : source.python, string.quoted.docstring.multi.python
\             : constant.language.python, source.python, string.quoted.docstring.multi.python
    foo       : source.python, string.quoted.docstring.multi.python
\'            : constant.character.escape.python, source.python, string.quoted.docstring.multi.python
              : source.python, string.quoted.docstring.multi.python
\"            : constant.character.escape.python, source.python, string.quoted.docstring.multi.python
              : source.python, string.quoted.docstring.multi.python
\a            : constant.character.escape.python, source.python, string.quoted.docstring.multi.python
              : source.python, string.quoted.docstring.multi.python
\b            : constant.character.escape.python, source.python, string.quoted.docstring.multi.python
 \c           : source.python, string.quoted.docstring.multi.python
\f            : constant.character.escape.python, source.python, string.quoted.docstring.multi.python
              : source.python, string.quoted.docstring.multi.python
\n            : constant.character.escape.python, source.python, string.quoted.docstring.multi.python
              : source.python, string.quoted.docstring.multi.python
\r            : constant.character.escape.python, source.python, string.quoted.docstring.multi.python
              : source.python, string.quoted.docstring.multi.python
\t            : constant.character.escape.python, source.python, string.quoted.docstring.multi.python
              : source.python, string.quoted.docstring.multi.python
\v            : constant.character.escape.python, source.python, string.quoted.docstring.multi.python
              : source.python, string.quoted.docstring.multi.python
\5            : constant.character.escape.python, source.python, string.quoted.docstring.multi.python
              : source.python, string.quoted.docstring.multi.python
\55           : constant.character.escape.python, source.python, string.quoted.docstring.multi.python
              : source.python, string.quoted.docstring.multi.python
\555          : constant.character.escape.python, source.python, string.quoted.docstring.multi.python
              : source.python, string.quoted.docstring.multi.python
\05           : constant.character.escape.python, source.python, string.quoted.docstring.multi.python
              : source.python, string.quoted.docstring.multi.python
\005          : constant.character.escape.python, source.python, string.quoted.docstring.multi.python
              : source.python, string.quoted.docstring.multi.python
    multiline "unicode" string  : source.python, string.quoted.docstring.multi.python
\             : constant.language.python, source.python, string.quoted.docstring.multi.python
              : source.python, string.quoted.docstring.multi.python
\xf1          : constant.character.escape.python, source.python, string.quoted.docstring.multi.python
              : source.python, string.quoted.docstring.multi.python
\u1234        : constant.character.escape.python, source.python, string.quoted.docstring.multi.python
aaaa          : source.python, string.quoted.docstring.multi.python
\U1234aaaa    : constant.character.escape.python, source.python, string.quoted.docstring.multi.python
              : source.python, string.quoted.docstring.multi.python
\N{BLACK SPADE SUIT} : constant.character.escape.python, source.python, string.quoted.docstring.multi.python
'''           : punctuation.definition.string.end.python, source.python, string.quoted.docstring.multi.python
