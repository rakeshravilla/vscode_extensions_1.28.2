123
000
123_456
1_2_3_4_5_6



123           : constant.numeric.dec.python, source.python
000           : constant.numeric.dec.python, source.python
123_456       : constant.numeric.dec.python, source.python
1_2_3_4_5_6   : constant.numeric.dec.python, source.python
