"""
    def foo():
        ...
        >>>
"""



"""           : punctuation.definition.string.begin.python, source.python, string.quoted.docstring.multi.python
    def foo(): : source.python, string.quoted.docstring.multi.python
        ...   : source.python, string.quoted.docstring.multi.python
        >>>   : source.python, string.quoted.docstring.multi.python
"""           : punctuation.definition.string.end.python, source.python, string.quoted.docstring.multi.python
