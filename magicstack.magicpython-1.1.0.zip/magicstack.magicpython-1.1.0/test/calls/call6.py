f(  *a ,  *())
f(  **a ,  **{})



f             : meta.function-call.generic.python, meta.function-call.python, source.python
(             : meta.function-call.python, punctuation.definition.arguments.begin.python, source.python
              : meta.function-call.arguments.python, meta.function-call.python, source.python
*             : keyword.operator.unpacking.arguments.python, meta.function-call.arguments.python, meta.function-call.python, source.python
a             : meta.function-call.arguments.python, meta.function-call.python, source.python
              : meta.function-call.arguments.python, meta.function-call.python, source.python
,             : meta.function-call.arguments.python, meta.function-call.python, punctuation.separator.arguments.python, source.python
              : meta.function-call.arguments.python, meta.function-call.python, source.python
*             : keyword.operator.unpacking.arguments.python, meta.function-call.arguments.python, meta.function-call.python, source.python
(             : meta.function-call.arguments.python, meta.function-call.python, punctuation.parenthesis.begin.python, source.python
)             : meta.function-call.arguments.python, meta.function-call.python, punctuation.parenthesis.end.python, source.python
)             : meta.function-call.python, punctuation.definition.arguments.end.python, source.python
f             : meta.function-call.generic.python, meta.function-call.python, source.python
(             : meta.function-call.python, punctuation.definition.arguments.begin.python, source.python
              : meta.function-call.arguments.python, meta.function-call.python, source.python
**            : keyword.operator.unpacking.arguments.python, meta.function-call.arguments.python, meta.function-call.python, source.python
a             : meta.function-call.arguments.python, meta.function-call.python, source.python
              : meta.function-call.arguments.python, meta.function-call.python, source.python
,             : meta.function-call.arguments.python, meta.function-call.python, punctuation.separator.arguments.python, source.python
              : meta.function-call.arguments.python, meta.function-call.python, source.python
**            : keyword.operator.unpacking.arguments.python, meta.function-call.arguments.python, meta.function-call.python, source.python
{             : meta.function-call.arguments.python, meta.function-call.python, punctuation.definition.dict.begin.python, source.python
}             : meta.function-call.arguments.python, meta.function-call.python, punctuation.definition.dict.end.python, source.python
)             : meta.function-call.python, punctuation.definition.arguments.end.python, source.python
