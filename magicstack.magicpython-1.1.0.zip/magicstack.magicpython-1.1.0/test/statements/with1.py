with a as b, c as d:
    pass



with          : keyword.control.flow.python, source.python
              : source.python
a             : source.python
              : source.python
as            : keyword.control.flow.python, source.python
              : source.python
b             : source.python
,             : punctuation.separator.element.python, source.python
              : source.python
c             : source.python
              : source.python
as            : keyword.control.flow.python, source.python
              : source.python
d             : source.python
:             : punctuation.separator.colon.python, source.python
              : source.python
pass          : keyword.control.flow.python, source.python
