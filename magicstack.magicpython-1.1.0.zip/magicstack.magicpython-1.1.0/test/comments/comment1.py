# XXX foo
# FIXME: bug
# NB: XXXx xXXX but XXX!
# ALSO HACK and NOTE and TODO highlight XXX and FIXME.



#             : comment.line.number-sign.python, punctuation.definition.comment.python, source.python
              : comment.line.number-sign.python, source.python
XXX           : comment.line.number-sign.python, keyword.codetag.notation.python, source.python
 foo          : comment.line.number-sign.python, source.python
#             : comment.line.number-sign.python, punctuation.definition.comment.python, source.python
              : comment.line.number-sign.python, source.python
FIXME         : comment.line.number-sign.python, keyword.codetag.notation.python, source.python
: bug         : comment.line.number-sign.python, source.python
#             : comment.line.number-sign.python, punctuation.definition.comment.python, source.python
 NB: XXXx xXXX but  : comment.line.number-sign.python, source.python
XXX           : comment.line.number-sign.python, keyword.codetag.notation.python, source.python
!             : comment.line.number-sign.python, source.python
#             : comment.line.number-sign.python, punctuation.definition.comment.python, source.python
 ALSO         : comment.line.number-sign.python, source.python
HACK          : comment.line.number-sign.python, keyword.codetag.notation.python, source.python
 and          : comment.line.number-sign.python, source.python
NOTE          : comment.line.number-sign.python, keyword.codetag.notation.python, source.python
 and          : comment.line.number-sign.python, source.python
TODO          : comment.line.number-sign.python, keyword.codetag.notation.python, source.python
 highlight    : comment.line.number-sign.python, source.python
XXX           : comment.line.number-sign.python, keyword.codetag.notation.python, source.python
 and          : comment.line.number-sign.python, source.python
FIXME         : comment.line.number-sign.python, keyword.codetag.notation.python, source.python
.             : comment.line.number-sign.python, source.python
