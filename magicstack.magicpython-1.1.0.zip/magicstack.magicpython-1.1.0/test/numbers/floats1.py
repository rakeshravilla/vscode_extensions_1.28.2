123.456
0.456
000.0001
.01234
123e5
123e-5
000123e-005
123.456e+5
0.456e-5



123.456       : constant.numeric.float.python, source.python
0.456         : constant.numeric.float.python, source.python
000.0001      : constant.numeric.float.python, source.python
.01234        : constant.numeric.float.python, source.python
123e5         : constant.numeric.float.python, source.python
123e-5        : constant.numeric.float.python, source.python
000123e-005   : constant.numeric.float.python, source.python
123.456e+5    : constant.numeric.float.python, source.python
0.456e-5      : constant.numeric.float.python, source.python
