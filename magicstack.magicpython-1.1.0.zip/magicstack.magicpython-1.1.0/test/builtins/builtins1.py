AttributeError ConnectionAbortedError
PendingDeprecationWarning
ModuleNotFoundError
SystemExit
NotImplemented True None False Ellipsis
Warning
Exception BaseException
sum oct abs type object print exec



AttributeError : source.python, support.type.exception.python
              : source.python
ConnectionAbortedError : source.python, support.type.exception.python
PendingDeprecationWarning : source.python, support.type.exception.python
ModuleNotFoundError : source.python, support.type.exception.python
SystemExit    : source.python, support.type.exception.python
NotImplemented : constant.language.python, source.python
              : source.python
True          : constant.language.python, source.python
              : source.python
None          : constant.language.python, source.python
              : source.python
False         : constant.language.python, source.python
              : source.python
Ellipsis      : constant.language.python, source.python
Warning       : source.python, support.type.exception.python
Exception     : source.python, support.type.exception.python
              : source.python
BaseException : source.python, support.type.exception.python
sum           : source.python, support.function.builtin.python
              : source.python
oct           : source.python, support.function.builtin.python
              : source.python
abs           : source.python, support.function.builtin.python
              : source.python
type          : source.python, support.type.python
              : source.python
object        : source.python, support.type.python
              : source.python
print         : source.python, support.function.builtin.python
              : source.python
exec          : source.python, support.function.builtin.python
