3.141_592j
10_000.j
10_000j
.001_123j
1e10_000j
3.141_592e-10_000j



3.141_592     : constant.numeric.float.python, source.python
j             : constant.numeric.float.python, source.python, storage.type.imaginary.number.python
10_000.       : constant.numeric.float.python, source.python
j             : constant.numeric.float.python, source.python, storage.type.imaginary.number.python
10_000        : constant.numeric.dec.python, source.python
j             : constant.numeric.dec.python, source.python, storage.type.imaginary.number.python
.001_123      : constant.numeric.float.python, source.python
j             : constant.numeric.float.python, source.python, storage.type.imaginary.number.python
1e10_000      : constant.numeric.float.python, source.python
j             : constant.numeric.float.python, source.python, storage.type.imaginary.number.python
3.141_592e-10_000 : constant.numeric.float.python, source.python
j             : constant.numeric.float.python, source.python, storage.type.imaginary.number.python
