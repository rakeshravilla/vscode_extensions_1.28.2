a = U'S T R'
a = B'S T R'
a = R'S T R'
a = BR'S T R'
a = RB'S T R'



a             : source.python
              : source.python
=             : keyword.operator.assignment.python, source.python
              : source.python
U             : source.python, storage.type.string.python, string.quoted.single.python
'             : punctuation.definition.string.begin.python, source.python, string.quoted.single.python
S T R         : source.python, string.quoted.single.python
'             : punctuation.definition.string.end.python, source.python, string.quoted.single.python
a             : source.python
              : source.python
=             : keyword.operator.assignment.python, source.python
              : source.python
B             : source.python, storage.type.string.python, string.quoted.binary.single.python
'             : punctuation.definition.string.begin.python, source.python, string.quoted.binary.single.python
S T R         : source.python, string.quoted.binary.single.python
'             : punctuation.definition.string.end.python, source.python, string.quoted.binary.single.python
a             : source.python
              : source.python
=             : keyword.operator.assignment.python, source.python
              : source.python
R             : source.python, storage.type.string.python, string.quoted.raw.single.python
'             : punctuation.definition.string.begin.python, source.python, string.quoted.raw.single.python
S T R         : source.python, string.quoted.raw.single.python
'             : punctuation.definition.string.end.python, source.python, string.quoted.raw.single.python
a             : source.python
              : source.python
=             : keyword.operator.assignment.python, source.python
              : source.python
BR            : source.python, storage.type.string.python, string.quoted.raw.binary.single.python
'             : punctuation.definition.string.begin.python, source.python, string.quoted.raw.binary.single.python
S T R         : source.python, string.quoted.raw.binary.single.python
'             : punctuation.definition.string.end.python, source.python, string.quoted.raw.binary.single.python
a             : source.python
              : source.python
=             : keyword.operator.assignment.python, source.python
              : source.python
RB            : source.python, storage.type.string.python, string.quoted.raw.binary.single.python
'             : punctuation.definition.string.begin.python, source.python, string.quoted.raw.binary.single.python
S T R         : source.python, string.quoted.raw.binary.single.python
'             : punctuation.definition.string.end.python, source.python, string.quoted.raw.binary.single.python
