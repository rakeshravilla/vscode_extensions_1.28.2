as async await continue del assert break finally for
from elif else if import except pass raise
return try while with

nonlocal global class def



as            : keyword.control.flow.python, source.python
              : source.python
async         : keyword.control.flow.python, source.python
              : source.python
await         : keyword.control.flow.python, source.python
              : source.python
continue      : keyword.control.flow.python, source.python
              : source.python
del           : keyword.control.flow.python, source.python
              : source.python
assert        : keyword.control.flow.python, source.python
              : source.python
break         : keyword.control.flow.python, source.python
              : source.python
finally       : keyword.control.flow.python, source.python
              : source.python
for           : keyword.control.flow.python, source.python
from          : keyword.control.flow.python, source.python
              : source.python
elif          : keyword.control.flow.python, source.python
              : source.python
else          : keyword.control.flow.python, source.python
              : source.python
if            : keyword.control.flow.python, source.python
              : source.python
import        : keyword.control.import.python, source.python
              : source.python
except        : keyword.control.flow.python, source.python
              : source.python
pass          : keyword.control.flow.python, source.python
              : source.python
raise         : keyword.control.flow.python, source.python
return        : keyword.control.flow.python, source.python
              : source.python
try           : keyword.control.flow.python, source.python
              : source.python
while         : keyword.control.flow.python, source.python
              : source.python
with          : keyword.control.flow.python, source.python
              : source.python
nonlocal      : source.python, storage.modifier.declaration.python
              : source.python
global        : source.python, storage.modifier.declaration.python
              : source.python
class         : source.python, storage.type.class.python
 def          : source.python, storage.type.function.python
