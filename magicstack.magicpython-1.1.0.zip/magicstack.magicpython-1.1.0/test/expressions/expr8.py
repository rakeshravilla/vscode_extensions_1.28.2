assert a or b, 'aaa'



assert        : keyword.control.flow.python, source.python
              : source.python
a             : source.python
              : source.python
or            : keyword.operator.logical.python, source.python
              : source.python
b             : source.python
,             : punctuation.separator.element.python, source.python
              : source.python
'             : punctuation.definition.string.begin.python, source.python, string.quoted.single.python
aaa           : source.python, string.quoted.single.python
'             : punctuation.definition.string.end.python, source.python, string.quoted.single.python
