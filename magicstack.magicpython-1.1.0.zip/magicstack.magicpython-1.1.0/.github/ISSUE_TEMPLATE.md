<!--
Thanks for wanting to report an issue you've found in MagicPython.
If this is a bug report, then please fill in the template below.

Thank you!
-->

* **Editor name and version**:
* **Platform**:
* **Color scheme**:
* **MagicPython version**:
* **A sreenshot**:
* **5-10 lines of surrounding code**:
