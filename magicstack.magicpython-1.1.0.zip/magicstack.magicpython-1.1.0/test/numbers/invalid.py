0123
0123l
123f
123d
123A
123__456
123_



0             : constant.numeric.dec.python, source.python
123           : constant.numeric.dec.python, invalid.illegal.dec.python, source.python
0123l         : invalid.illegal.name.python, source.python
123f          : invalid.illegal.name.python, source.python
123d          : invalid.illegal.name.python, source.python
123A          : invalid.illegal.name.python, source.python
123__456      : invalid.illegal.name.python, source.python
123_          : invalid.illegal.name.python, source.python
