async = await = 2



async         : keyword.control.flow.python, source.python
              : source.python
=             : keyword.operator.assignment.python, source.python
              : source.python
await         : keyword.control.flow.python, source.python
              : source.python
=             : keyword.operator.assignment.python, source.python
              : source.python
2             : constant.numeric.dec.python, source.python
