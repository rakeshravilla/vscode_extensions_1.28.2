from __future__ import generator_stop



from          : keyword.control.flow.python, source.python
              : source.python
__future__    : source.python, support.variable.magic.python
              : source.python
import        : keyword.control.import.python, source.python
              : source.python
generator_stop : source.python
