some. True
some. \
    True
True
some.
    True



some          : source.python
.             : punctuation.separator.period.python, source.python
              : source.python
True          : keyword.illegal.name.python, source.python
some          : source.python
.             : punctuation.separator.period.python, source.python
              : source.python
\             : punctuation.separator.continuation.line.python, source.python
              : source.python
              : source.python
True          : keyword.illegal.name.python, source.python
True          : constant.language.python, source.python
some          : source.python
.             : punctuation.separator.period.python, source.python
              : source.python
              : source.python
True          : keyword.illegal.name.python, source.python
