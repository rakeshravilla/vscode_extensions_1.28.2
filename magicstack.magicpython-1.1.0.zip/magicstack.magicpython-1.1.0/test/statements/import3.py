from....import a
from...import b
from..import c
from.import d



from          : keyword.control.import.python, source.python
....          : punctuation.separator.period.python, source.python
import        : keyword.control.import.python, source.python
              : source.python
a             : source.python
from          : keyword.control.import.python, source.python
...           : punctuation.separator.period.python, source.python
import        : keyword.control.import.python, source.python
              : source.python
b             : source.python
from          : keyword.control.import.python, source.python
..            : punctuation.separator.period.python, source.python
import        : keyword.control.import.python, source.python
              : source.python
c             : source.python
from          : keyword.control.import.python, source.python
.             : punctuation.separator.period.python, source.python
import        : keyword.control.import.python, source.python
              : source.python
d             : source.python
