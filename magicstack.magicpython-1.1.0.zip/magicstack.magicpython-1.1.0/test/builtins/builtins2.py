Error
file reduce intern raw_input unicode cmp basestring execfile long xrange apply



Error         : source.python
file          : source.python, variable.legacy.builtin.python
              : source.python
reduce        : source.python, variable.legacy.builtin.python
              : source.python
intern        : source.python, variable.legacy.builtin.python
              : source.python
raw_input     : source.python, variable.legacy.builtin.python
              : source.python
unicode       : source.python, variable.legacy.builtin.python
              : source.python
cmp           : source.python, variable.legacy.builtin.python
              : source.python
basestring    : source.python, variable.legacy.builtin.python
              : source.python
execfile      : source.python, variable.legacy.builtin.python
              : source.python
long          : source.python, variable.legacy.builtin.python
              : source.python
xrange        : source.python, variable.legacy.builtin.python
              : source.python
apply         : source.python
