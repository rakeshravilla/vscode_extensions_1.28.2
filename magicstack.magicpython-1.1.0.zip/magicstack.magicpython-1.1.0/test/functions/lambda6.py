anon = lambda a=123, c={'': 555}, \
              d=toow(24): None



anon          : source.python
              : source.python
=             : keyword.operator.assignment.python, source.python
              : source.python
lambda        : meta.lambda-function.python, source.python, storage.type.function.lambda.python
              : meta.function.lambda.parameters.python, meta.lambda-function.python, source.python
a             : meta.function.lambda.parameters.python, meta.lambda-function.python, source.python, variable.parameter.function.language.python
=             : keyword.operator.python, meta.function.lambda.parameters.python, meta.lambda-function.python, source.python
123           : constant.numeric.dec.python, meta.function.lambda.parameters.python, meta.lambda-function.python, source.python
,             : meta.function.lambda.parameters.python, meta.lambda-function.python, punctuation.separator.parameters.python, source.python
              : meta.function.lambda.parameters.python, meta.lambda-function.python, source.python
c             : meta.function.lambda.parameters.python, meta.lambda-function.python, source.python, variable.parameter.function.language.python
=             : keyword.operator.python, meta.function.lambda.parameters.python, meta.lambda-function.python, source.python
{             : meta.function.lambda.parameters.python, meta.lambda-function.python, punctuation.definition.dict.begin.python, source.python
'             : meta.function.lambda.parameters.python, meta.lambda-function.python, punctuation.definition.string.begin.python, source.python, string.quoted.single.python
'             : meta.function.lambda.parameters.python, meta.lambda-function.python, punctuation.definition.string.end.python, source.python, string.quoted.single.python
:             : meta.function.lambda.parameters.python, meta.lambda-function.python, punctuation.separator.dict.python, source.python
              : meta.function.lambda.parameters.python, meta.lambda-function.python, source.python
555           : constant.numeric.dec.python, meta.function.lambda.parameters.python, meta.lambda-function.python, source.python
}             : meta.function.lambda.parameters.python, meta.lambda-function.python, punctuation.definition.dict.end.python, source.python
,             : meta.function.lambda.parameters.python, meta.lambda-function.python, punctuation.separator.parameters.python, source.python
              : meta.function.lambda.parameters.python, meta.lambda-function.python, source.python
\             : meta.function.lambda.parameters.python, meta.lambda-function.python, punctuation.separator.continuation.line.python, source.python
              : meta.function.lambda.parameters.python, meta.lambda-function.python, source.python
               : meta.function.lambda.parameters.python, meta.lambda-function.python, source.python
d             : meta.function.lambda.parameters.python, meta.lambda-function.python, source.python, variable.parameter.function.language.python
=             : keyword.operator.python, meta.function.lambda.parameters.python, meta.lambda-function.python, source.python
toow          : meta.function-call.generic.python, meta.function-call.python, meta.function.lambda.parameters.python, meta.lambda-function.python, source.python
(             : meta.function-call.python, meta.function.lambda.parameters.python, meta.lambda-function.python, punctuation.definition.arguments.begin.python, source.python
24            : constant.numeric.dec.python, meta.function-call.arguments.python, meta.function-call.python, meta.function.lambda.parameters.python, meta.lambda-function.python, source.python
)             : meta.function-call.python, meta.function.lambda.parameters.python, meta.lambda-function.python, punctuation.definition.arguments.end.python, source.python
:             : meta.lambda-function.python, punctuation.section.function.lambda.begin.python, source.python
              : source.python
None          : constant.language.python, source.python
