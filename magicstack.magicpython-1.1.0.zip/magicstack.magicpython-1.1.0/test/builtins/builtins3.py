__all__ = ['bar', 'baz']
some.__bases__
some.__class__
assert __debug__
__builtins__
__builtins__.len
print(__builtins__)
some.__dict__
some.__doc__
some.__file__
some.__members__
some.__metaclass__
some.__methods__
some.__module__
some.__mro__
some.__name__
some.__slots__
some.__subclasses__
some.__version__
some.__weakref__
some.__qualname__
some.__code__
some.__wrapped__
some.__signature__
some.__defaults__
some.__func__
some.__self__
some.__kwdefaults__
some.__matmul__
some.__imatmul__
some.__rmatmul__
some.__annotations__
some.__init_subclass__
some.__set_name__
some.__fspath__
some.__classcell__
some.__bytes__
some.__spec__
some.__path__
some.__prepare__
some.__package__
some.__traceback__
some.__notspecial__




__all__       : source.python, support.variable.magic.python
              : source.python
=             : keyword.operator.assignment.python, source.python
              : source.python
[             : punctuation.definition.list.begin.python, source.python
'             : punctuation.definition.string.begin.python, source.python, string.quoted.single.python
bar           : source.python, string.quoted.single.python
'             : punctuation.definition.string.end.python, source.python, string.quoted.single.python
,             : punctuation.separator.element.python, source.python
              : source.python
'             : punctuation.definition.string.begin.python, source.python, string.quoted.single.python
baz           : source.python, string.quoted.single.python
'             : punctuation.definition.string.end.python, source.python, string.quoted.single.python
]             : punctuation.definition.list.end.python, source.python
some          : source.python
.             : punctuation.separator.period.python, source.python
__bases__     : source.python, support.variable.magic.python
some          : source.python
.             : punctuation.separator.period.python, source.python
__class__     : source.python, support.variable.magic.python
assert        : keyword.control.flow.python, source.python
              : source.python
__debug__     : source.python, support.variable.magic.python
__builtins__  : source.python, support.variable.magic.python
__builtins__  : source.python, support.variable.magic.python
.             : punctuation.separator.period.python, source.python
len           : source.python
print         : meta.function-call.python, source.python, support.function.builtin.python
(             : meta.function-call.python, punctuation.definition.arguments.begin.python, source.python
__builtins__  : meta.function-call.arguments.python, meta.function-call.python, source.python, support.variable.magic.python
)             : meta.function-call.python, punctuation.definition.arguments.end.python, source.python
some          : source.python
.             : punctuation.separator.period.python, source.python
__dict__      : source.python, support.variable.magic.python
some          : source.python
.             : punctuation.separator.period.python, source.python
__doc__       : source.python, support.variable.magic.python
some          : source.python
.             : punctuation.separator.period.python, source.python
__file__      : source.python, support.variable.magic.python
some          : source.python
.             : punctuation.separator.period.python, source.python
__members__   : source.python, support.variable.magic.python
some          : source.python
.             : punctuation.separator.period.python, source.python
__metaclass__ : source.python, support.variable.magic.python
some          : source.python
.             : punctuation.separator.period.python, source.python
__methods__   : source.python, support.variable.magic.python
some          : source.python
.             : punctuation.separator.period.python, source.python
__module__    : source.python, support.variable.magic.python
some          : source.python
.             : punctuation.separator.period.python, source.python
__mro__       : source.python, support.variable.magic.python
some          : source.python
.             : punctuation.separator.period.python, source.python
__name__      : source.python, support.variable.magic.python
some          : source.python
.             : punctuation.separator.period.python, source.python
__slots__     : source.python, support.variable.magic.python
some          : source.python
.             : punctuation.separator.period.python, source.python
__subclasses__ : source.python, support.variable.magic.python
some          : source.python
.             : punctuation.separator.period.python, source.python
__version__   : source.python, support.variable.magic.python
some          : source.python
.             : punctuation.separator.period.python, source.python
__weakref__   : source.python, support.variable.magic.python
some          : source.python
.             : punctuation.separator.period.python, source.python
__qualname__  : source.python, support.variable.magic.python
some          : source.python
.             : punctuation.separator.period.python, source.python
__code__      : source.python, support.variable.magic.python
some          : source.python
.             : punctuation.separator.period.python, source.python
__wrapped__   : source.python, support.variable.magic.python
some          : source.python
.             : punctuation.separator.period.python, source.python
__signature__ : source.python, support.variable.magic.python
some          : source.python
.             : punctuation.separator.period.python, source.python
__defaults__  : source.python, support.variable.magic.python
some          : source.python
.             : punctuation.separator.period.python, source.python
__func__      : source.python, support.variable.magic.python
some          : source.python
.             : punctuation.separator.period.python, source.python
__self__      : source.python, support.variable.magic.python
some          : source.python
.             : punctuation.separator.period.python, source.python
__kwdefaults__ : source.python, support.variable.magic.python
some          : source.python
.             : punctuation.separator.period.python, source.python
__matmul__    : source.python, support.function.magic.python
some          : source.python
.             : punctuation.separator.period.python, source.python
__imatmul__   : source.python, support.function.magic.python
some          : source.python
.             : punctuation.separator.period.python, source.python
__rmatmul__   : source.python, support.function.magic.python
some          : source.python
.             : punctuation.separator.period.python, source.python
__annotations__ : source.python, support.variable.magic.python
some          : source.python
.             : punctuation.separator.period.python, source.python
__init_subclass__ : source.python, support.function.magic.python
some          : source.python
.             : punctuation.separator.period.python, source.python
__set_name__  : source.python, support.function.magic.python
some          : source.python
.             : punctuation.separator.period.python, source.python
__fspath__    : source.python, support.function.magic.python
some          : source.python
.             : punctuation.separator.period.python, source.python
__classcell__ : source.python, support.variable.magic.python
some          : source.python
.             : punctuation.separator.period.python, source.python
__bytes__     : source.python, support.function.magic.python
some          : source.python
.             : punctuation.separator.period.python, source.python
__spec__      : source.python, support.variable.magic.python
some          : source.python
.             : punctuation.separator.period.python, source.python
__path__      : source.python, support.variable.magic.python
some          : source.python
.             : punctuation.separator.period.python, source.python
__prepare__   : source.python, support.function.magic.python
some          : source.python
.             : punctuation.separator.period.python, source.python
__package__   : source.python, support.variable.magic.python
some          : source.python
.             : punctuation.separator.period.python, source.python
__traceback__ : source.python, support.variable.magic.python
some          : source.python
.             : punctuation.separator.period.python, source.python
__notspecial__ : source.python
