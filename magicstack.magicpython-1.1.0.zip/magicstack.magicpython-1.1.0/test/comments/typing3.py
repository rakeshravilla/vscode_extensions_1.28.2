# abc type: def



#             : comment.line.number-sign.python, punctuation.definition.comment.python, source.python
 abc type: def : comment.line.number-sign.python, source.python
