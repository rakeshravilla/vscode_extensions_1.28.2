a = `(1, `2`)`



a             : source.python
              : source.python
=             : keyword.operator.assignment.python, source.python
              : source.python
`             : invalid.deprecated.backtick.python, source.python
(             : invalid.deprecated.backtick.python, punctuation.parenthesis.begin.python, source.python
1             : constant.numeric.dec.python, invalid.deprecated.backtick.python, source.python
,             : invalid.deprecated.backtick.python, punctuation.separator.element.python, source.python
              : invalid.deprecated.backtick.python, source.python
`             : invalid.deprecated.backtick.python, source.python
2             : constant.numeric.dec.python, invalid.deprecated.backtick.python, source.python
`             : invalid.deprecated.backtick.python, source.python
)             : invalid.deprecated.backtick.python, punctuation.parenthesis.end.python, source.python
`             : invalid.deprecated.backtick.python, source.python
