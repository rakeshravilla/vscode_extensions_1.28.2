a = ...
a(..., c=...)
a = ((...), ...)
....__class__



a             : source.python
              : source.python
=             : keyword.operator.assignment.python, source.python
              : source.python
...           : constant.other.ellipsis.python, source.python
a             : meta.function-call.generic.python, meta.function-call.python, source.python
(             : meta.function-call.python, punctuation.definition.arguments.begin.python, source.python
...           : constant.other.ellipsis.python, meta.function-call.arguments.python, meta.function-call.python, source.python
,             : meta.function-call.arguments.python, meta.function-call.python, punctuation.separator.arguments.python, source.python
              : meta.function-call.arguments.python, meta.function-call.python, source.python
c             : meta.function-call.arguments.python, meta.function-call.python, source.python, variable.parameter.function-call.python
=             : keyword.operator.assignment.python, meta.function-call.arguments.python, meta.function-call.python, source.python
...           : constant.other.ellipsis.python, meta.function-call.arguments.python, meta.function-call.python, source.python
)             : meta.function-call.python, punctuation.definition.arguments.end.python, source.python
a             : source.python
              : source.python
=             : keyword.operator.assignment.python, source.python
              : source.python
(             : punctuation.parenthesis.begin.python, source.python
(             : punctuation.parenthesis.begin.python, source.python
...           : constant.other.ellipsis.python, source.python
)             : punctuation.parenthesis.end.python, source.python
,             : punctuation.separator.element.python, source.python
              : source.python
...           : constant.other.ellipsis.python, source.python
)             : punctuation.parenthesis.end.python, source.python
...           : constant.other.ellipsis.python, source.python
.             : punctuation.separator.period.python, source.python
__class__     : source.python, support.variable.magic.python
