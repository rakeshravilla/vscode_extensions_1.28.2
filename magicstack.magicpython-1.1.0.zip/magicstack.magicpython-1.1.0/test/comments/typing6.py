a=1#type:int
a=1#type:int#int



a             : source.python
=             : keyword.operator.assignment.python, source.python
1             : constant.numeric.dec.python, source.python
#             : comment.line.number-sign.python, meta.typehint.comment.python, source.python
type:         : comment.line.number-sign.python, comment.typehint.directive.notation.python, meta.typehint.comment.python, source.python
int           : comment.line.number-sign.python, comment.typehint.type.notation.python, meta.typehint.comment.python, source.python
a             : source.python
=             : keyword.operator.assignment.python, source.python
1             : constant.numeric.dec.python, source.python
#             : comment.line.number-sign.python, meta.typehint.comment.python, source.python
type:         : comment.line.number-sign.python, comment.typehint.directive.notation.python, meta.typehint.comment.python, source.python
int           : comment.line.number-sign.python, comment.typehint.type.notation.python, meta.typehint.comment.python, source.python
#             : comment.line.number-sign.python, punctuation.definition.comment.python, source.python
int           : comment.line.number-sign.python, source.python
