(a, *rest, b) = range(5)



(             : punctuation.parenthesis.begin.python, source.python
a             : source.python
,             : punctuation.separator.element.python, source.python
              : source.python
*             : keyword.operator.arithmetic.python, source.python
rest          : source.python
,             : punctuation.separator.element.python, source.python
              : source.python
b             : source.python
)             : punctuation.parenthesis.end.python, source.python
              : source.python
=             : keyword.operator.assignment.python, source.python
              : source.python
range         : meta.function-call.python, source.python, support.function.builtin.python
(             : meta.function-call.python, punctuation.definition.arguments.begin.python, source.python
5             : constant.numeric.dec.python, meta.function-call.arguments.python, meta.function-call.python, source.python
)             : meta.function-call.python, punctuation.definition.arguments.end.python, source.python
