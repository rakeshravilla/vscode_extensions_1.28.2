from .... import a
from ... import b
from .. import c



from          : keyword.control.import.python, source.python
              : source.python
....          : punctuation.separator.period.python, source.python
              : source.python
import        : keyword.control.import.python, source.python
              : source.python
a             : source.python
from          : keyword.control.import.python, source.python
              : source.python
...           : punctuation.separator.period.python, source.python
              : source.python
import        : keyword.control.import.python, source.python
              : source.python
b             : source.python
from          : keyword.control.import.python, source.python
              : source.python
..            : punctuation.separator.period.python, source.python
              : source.python
import        : keyword.control.import.python, source.python
              : source.python
c             : source.python
