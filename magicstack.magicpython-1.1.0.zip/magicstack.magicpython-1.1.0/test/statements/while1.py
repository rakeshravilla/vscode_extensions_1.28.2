while 1:
    pass



while         : keyword.control.flow.python, source.python
              : source.python
1             : constant.numeric.dec.python, source.python
:             : punctuation.separator.colon.python, source.python
              : source.python
pass          : keyword.control.flow.python, source.python
